using UnityEngine;
using GrassSim.AI;
using GrassSim.Combat;
using GrassSim.Core;

namespace GrassSim.Enemies
{
    public class EnemyCombatant : MonoBehaviour
    {
        public EnemyStatsData stats;
        public int simId = -1;

        public AudioSource audioSource;
        public AudioClip enemyDead1;
        public AudioClip enemyDead2;
        public AudioClip enemyDead3;
        public AudioClip enemyDead4;

        private bool handledDeath;

        // 🔥 WOŁANE PRZEZ Combatant.SendMessage
        private void OnCombatantDied()
        {
            if (handledDeath)
                return;
            
            EnemyDiedAudioPlay();
            handledDeath = true;

            if (stats == null) return;

            var player = FindFirstObjectByType<PlayerProgressionController>();
            if (player != null)
            {
                player.AddExp(stats.expReward);
            }

            // 1️⃣ wyłącz AI / collidery
            DisableEnemy();

            // 2️⃣ zgłoś do systemu aktywacji
            if (EnemyActivationController.Instance != null && simId >= 0)
            {
                EnemyActivationController.Instance.OnEnemyKilled(simId);
            }
            else
            {
                // fallback
                Destroy(gameObject);
            }
        }

        private void DisableEnemy()
        {
            // wyłącz collidery
            foreach (var c in GetComponentsInChildren<Collider>())
                c.enabled = false;

            // wyłącz AI
            foreach (var mb in GetComponents<MonoBehaviour>())
            {
                if (mb != this)
                    mb.enabled = false;
            }
        }

        private void EnemyDiedAudioPlay() 
        {
            AudioClip clip = null;
            
            int variant = Random.Range(0, 4);

            switch (variant) {
                case 0:
                    clip = enemyDead1;
                    break;
                case 1:
                    clip = enemyDead2;
                    break;
                case 2:
                    clip = enemyDead3;
                    break;
                case 3:
                    clip = enemyDead4;
                    break;
            }

            AudioUtils.PlayClipAtPoint(clip, transform.position, 1f);
        }
    }
}
