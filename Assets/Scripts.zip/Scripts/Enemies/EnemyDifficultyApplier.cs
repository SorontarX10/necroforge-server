using UnityEngine;
using GrassSim.Enemies;

public class EnemyDifficultyApplier : MonoBehaviour
{
    private EnemyCombatant combatant;

    private void Awake()
    {
        combatant = GetComponent<EnemyCombatant>();
        if (combatant == null)
            return;

        if (combatant.stats == null)
            return;

        // ❗️Kopiujemy staty, NIE DOTYKAMY ScriptableObject
        EnemyStatsData scaled = Instantiate(combatant.stats);

        scaled.maxHealth *= DifficultyContext.EnemyHealthMultiplier;
        scaled.damage *= DifficultyContext.EnemyDamageMultiplier;
        scaled.attackCooldown /= DifficultyContext.EnemyAttackSpeedMultiplier;

        combatant.stats = scaled;
    }
}
