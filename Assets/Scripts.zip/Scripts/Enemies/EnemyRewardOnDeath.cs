using UnityEngine;
using GrassSim.Core;
using GrassSim.Stats;

namespace GrassSim.Enemies
{
    public class EnemyRewardOnDeath : MonoBehaviour
    {
        private EnemyStatsData stats;

        private void Awake()
        {
            stats = GetComponent<EnemyCombatant>()?.stats;
        }

        public void GrantRewards()
        {
            if (stats == null)
                return;

            var player = FindFirstObjectByType<PlayerProgressionController>();
            if (player == null)
                return;

            int baseExp = stats.expReward;

            float diffMul = 1f;
            if (WorldStats.Instance != null)
                diffMul = 1f + 0.15f * (WorldStats.Instance.difficulty - 1);

            int finalExp = Mathf.RoundToInt(baseExp * diffMul);

            player.AddExp(finalExp);
        }
    }
}
