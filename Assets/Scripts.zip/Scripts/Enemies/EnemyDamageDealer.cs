using UnityEngine;
using GrassSim.Combat;
using GrassSim.Enemies;

public class EnemyDamageDealer : MonoBehaviour
{
    public float hitCooldown = 0.6f;

    public AudioSource audioSource;
    public AudioClip slash_1;
    public AudioClip slash_2;
    public AudioClip slash_3;

    [SerializeField]
    private LayerMask validTargetLayers;

    private Combatant owner;
    private EnemyCombatant enemy;
    private float lastHitTime;

    private void Awake()
    {
        owner = GetComponentInParent<Combatant>();
        enemy = GetComponentInParent<EnemyCombatant>();
    }

    private void OnTriggerEnter(Collider other)
    {
        TryDealDamage(other);
    }

    private void OnTriggerStay(Collider other)
    {
        TryDealDamage(other);
    }

    private void TryDealDamage(Collider other)
    {
        if ((validTargetLayers.value & (1 << other.gameObject.layer)) == 0)
            return;

        if (Time.time < lastHitTime + hitCooldown)
            return;

        Combatant target = other.GetComponentInParent<Combatant>();
        if (target == null || target == owner || target.IsDead)
            return;

        if (enemy == null || enemy.stats == null)
            return;

        float damage = enemy.stats.damage;

        SlashAudioPlay();
        target.TakeDamage(damage);
        lastHitTime = Time.time;
    }

    private void SlashAudioPlay()
    {
        if (audioSource == null)
            return;

        int clipVersion = Random.Range(0, 3);
        switch (clipVersion)
        {
            case 0: audioSource.PlayOneShot(slash_1); break;
            case 1: audioSource.PlayOneShot(slash_2); break;
            case 2: audioSource.PlayOneShot(slash_3); break;
        }
    }
}
