using UnityEngine;

public class ZombieDifficultyPerceptionScaler : MonoBehaviour
{
    [Header("Base perception (copied once)")]
    public float baseViewRadius;
    public float baseViewAngle;

    private ZombiePerception perception;

    void Awake()
    {
        perception = GetComponent<ZombiePerception>();
        if (!perception)
            return;

        // zapamiętaj wartości bazowe
        baseViewRadius = perception.viewRadius;
        baseViewAngle = perception.viewAngle;

        ApplyDifficulty();
    }

    void ApplyDifficulty()
    {
        int diff = DifficultyContext.Difficulty;

        // +7% zasięgu widzenia per difficulty
        perception.viewRadius = baseViewRadius * (1f + 0.07f * (diff - 1));

        // kąt widzenia zostawiamy STAŁY (ważne!)
        perception.viewAngle = baseViewAngle;
    }
}
