using UnityEngine;

public class ZombieCombatInput : MonoBehaviour, ICombatInput
{
    public ZombiePerception perception;
    public float attackDistance = 2.2f;

    void Awake()
    {
        if (!perception)
            perception = GetComponent<ZombiePerception>();
    }

    // ======================
    // ICombatInput
    // ======================

    public bool IsAttacking()
    {
        if (!perception || perception.VisibleEnemy == null)
            return false;

        float dist = Vector3.Distance(
            transform.position,
            perception.VisibleEnemy.position
        );

        return dist <= attackDistance;
    }

    public Vector2 GetSwingInput()
    {
        // Zombie nie używa swingów
        return Vector2.zero;
    }

    public Vector3 GetMoveDirection()
    {
        // Zombie NIE steruje ruchem przez ICombatInput
        return Vector3.zero;
    }
}
