using UnityEngine;
using GrassSim.Combat;
using GrassSim.Core;
using GrassSim.Stats;
using GrassSim.Enhancers;

public class WeaponController : MonoBehaviour
{
    [Header("References")]
    public Transform weaponPivot;
    public Combatant owner;
    public ICombatInput combatInputSource;
    [SerializeField] private Collider weaponHitbox;

    [Header("Swing Settings")]
    public float pitchSpeed = 220f;
    public float yawSpeed = 360f;
    public float deadzone = 0.01f;
    public float maxAnglePerFrame = 35f;

    [Header("Swing Speed Stat")]
    public float baseSwingSpeedMultiplier = 1f;

    [Header("Stamina")]
    public bool requireStamina = false;
    public float staminaDrainPerSecond = 12f;
    public float staminaRegenPerSecond = 10f;
    [Range(0.01f, 1f)]
    public float minSwingStaminaMultiplier = 0.01f;

    [Header("Bounce")]
    public float bouncePitchStrength = 25f;
    public float bounceYawStrength = 35f;
    public float bounceDamping = 0.85f;
    public float bounceStopThreshold = 0.5f;

    [Header("Debug")]
    public bool debugLogs = false;

    [Header("Audio – Sword Swing")]
    public AudioSource swingLoopSource;

    [Header("Swing Energy")]
    public float energyBuildSpeed = 2.5f;   // jak szybko rośnie przy ruchu
    public float energyDecaySpeed = 3.5f;   // jak szybko spada bez ruchu

    [Header("Inertia")]
    public float acceleration = 18f;
    public float deceleration = 22f;

    [Header("Reset")]
    public KeyCode resetKey = KeyCode.Mouse1;
    public float resetSpeed = 8f;

    private bool isResetting;


    private Vector2 swingVelocity;
    private float swingEnergy; // 0..1

    public float minSwingVolume = 0.05f;
    public float maxSwingVolume = 0.9f;

    public float minSwingPitch = 0.9f;
    public float maxSwingPitch = 1.1f;

    public float audioSmooth = 12f;

    [Header("Swing Settings")]
    public Vector2 lastSwing { get; private set; }
    public float lastSwingSpeed { get; private set; }
    public float lastSwingIntensity { get; private set; }

    private Quaternion lastRotation;

    private Vector2 bounceVelocity;
    private bool hasBounce;

    private PlayerProgressionController playerProg;
    private Quaternion weaponIdleLocalRot;
    private BaseCombatAgent agent;
    private bool attacking;

    private float nextDiagTime;
    private WeaponEnhancerSystem enhancerSystem;

    private void Awake()
    {
        if (weaponPivot == null) weaponPivot = transform;
        if (owner == null) owner = GetComponentInParent<Combatant>();
        if (combatInputSource == null) combatInputSource = GetComponentInParent<ICombatInput>();

        playerProg = GetComponentInParent<PlayerProgressionController>();
        if (playerProg != null)
            playerProg.OnUpgradeMenuStateChanged += HandleUpgradeMenuState;

        weaponIdleLocalRot = weaponPivot.localRotation;
        agent = GetComponentInParent<BaseCombatAgent>();

        lastRotation = weaponPivot.rotation;
        enhancerSystem = GetComponentInChildren<WeaponEnhancerSystem>(true);

        if (swingLoopSource != null)
        {
            swingLoopSource.loop = true;
            swingLoopSource.playOnAwake = false;
        }
    }

    private void Update()
    {
        if (playerProg != null && playerProg.IsChoosingUpgrade)
        {
            if (swingLoopSource != null && swingLoopSource.isPlaying)
                swingLoopSource.Stop();
            return;
        }

        if (owner == null || owner.IsDead) return;
        if (weaponPivot == null || combatInputSource == null) return;

        // 🔁 RESET (PPM) – tylko gdy NIE atakujemy
        if (!combatInputSource.IsAttacking() && Input.GetKeyDown(resetKey))
            isResetting = true;

        if (isResetting)
        {
            weaponPivot.localRotation = Quaternion.Slerp(
                weaponPivot.localRotation,
                weaponIdleLocalRot,
                Time.deltaTime * resetSpeed
            );

            if (Quaternion.Angle(weaponPivot.localRotation, weaponIdleLocalRot) < 0.5f)
            {
                weaponPivot.localRotation = weaponIdleLocalRot;
                isResetting = false;
            }

            UpdateSwingAudio();
            return;
        }

        if (hasBounce)
        {
            ApplyBounce();
            return;
        }

        if (!combatInputSource.IsAttacking())
        {
            TryRegenerateStamina(Time.deltaTime);
            lastSwing = Vector2.zero;
            lastSwingSpeed = 0f;
            lastSwingIntensity = 0f;
            lastRotation = weaponPivot.rotation;

            swingEnergy = Mathf.MoveTowards(
                swingEnergy,
                0f,
                energyDecaySpeed * Time.deltaTime
            );

            swingVelocity = Vector2.Lerp(
                swingVelocity,
                Vector2.zero,
                deceleration * Time.deltaTime
            );

            lastSwingIntensity = swingEnergy * swingEnergy;
            UpdateSwingAudio();
            return;
        }

        Vector2 swing = combatInputSource.GetSwingInput();
        if (swing.sqrMagnitude < deadzone * deadzone)
        {
            UpdateSwingAudio();
            return;
        }

        lastSwing = swing;

        float swingSpeed = Mathf.Clamp01(swing.magnitude / 50f);
        float swingSpeedMul = GetSwingSpeedMultiplier();

        swingEnergy += swingSpeed * energyBuildSpeed * swingSpeedMul * Time.deltaTime;
        swingEnergy = Mathf.Clamp01(swingEnergy);

        float staminaMul = GetStaminaSwingMultiplier();

        lastSwingIntensity =
            swingEnergy * staminaMul *
            Mathf.Lerp(0.8f, 1.25f, Mathf.Clamp01(swingSpeedMul - 1f));

        TryDrainStamina(lastSwingIntensity);

        Vector2 targetVelocity = swing * new Vector2(
            yawSpeed * swingSpeedMul,
            pitchSpeed * swingSpeedMul
        );

        swingVelocity = Vector2.Lerp(
            swingVelocity,
            targetVelocity,
            acceleration * Time.deltaTime
        );

        float yaw = -swingVelocity.x * Time.deltaTime;
        float pitch = -swingVelocity.y * Time.deltaTime;

        yaw = Mathf.Clamp(yaw, -maxAnglePerFrame, maxAnglePerFrame);
        pitch = Mathf.Clamp(pitch, -maxAnglePerFrame, maxAnglePerFrame);

        yaw *= staminaMul;
        pitch *= staminaMul;

        weaponPivot.Rotate(Vector3.right, pitch, Space.Self);
        weaponPivot.Rotate(Vector3.forward, yaw, Space.Self);

        float deltaAngle = Quaternion.Angle(lastRotation, weaponPivot.rotation);
        lastSwingSpeed = deltaAngle / Mathf.Max(Time.deltaTime, 0.0001f);
        lastRotation = weaponPivot.rotation;

        UpdateSwingAudio();
    }

    public void AddBounce(Vector3 collisionNormalWorld)
    {
        if (weaponPivot == null) weaponPivot = transform;

        Vector3 localNormal = weaponPivot.InverseTransformDirection(collisionNormalWorld);
        float k = Mathf.Max(0.25f, lastSwingIntensity);

        bounceVelocity = new Vector2(
            -localNormal.x * bounceYawStrength * k,
            -localNormal.y * bouncePitchStrength * k
        );

        hasBounce = true;
    }

    private void ApplyBounce()
    {
        Vector2 delta = bounceVelocity * Time.deltaTime;

        weaponPivot.Rotate(Vector3.right, delta.y, Space.Self);
        weaponPivot.Rotate(Vector3.forward, delta.x, Space.Self);

        bounceVelocity *= bounceDamping;

        if (bounceVelocity.magnitude < bounceStopThreshold)
        {
            bounceVelocity = Vector2.zero;
            hasBounce = false;
        }
    }

    private bool TryDrainStamina(float dt)
    {
        float cost = Mathf.Sqrt(staminaDrainPerSecond * dt);

        if (playerProg == null && agent == null)
            return !requireStamina;

        if (playerProg != null)
        {
            bool ok = playerProg.TrySpendStamina(cost);
            return ok || !requireStamina;
        }

        if (agent != null)
        {
            if (agent.stamina >= cost)
            {
                agent.stamina -= cost;
                return true;
            }
            return !requireStamina;
        }

        return !requireStamina;
    }

    private void TryRegenerateStamina(float dt)
    {
        float regen = staminaRegenPerSecond * dt;

        if (playerProg != null)
        {
            playerProg.AddStamina(regen);
            return;
        }

        if (agent != null)
        {
            agent.stamina = Mathf.Min(agent.stamina + regen, agent.maxStamina);
        }
    }

    public float GetLastSwingIntensity()
    {
        return lastSwingIntensity;
    }

    private void UpdateSwingAudio()
    {
        if (swingLoopSource == null)
            return;

        attacking = combatInputSource != null && combatInputSource.IsAttacking();

        if (!attacking || lastSwingIntensity <= deadzone)
        {
            // Fade out
            swingLoopSource.volume = Mathf.Lerp(
                swingLoopSource.volume,
                0f,
                Time.deltaTime * audioSmooth
            );

            if (swingLoopSource.volume < 0.01f && swingLoopSource.isPlaying)
                swingLoopSource.Stop();

            return;
        }

        if (!swingLoopSource.isPlaying)
            swingLoopSource.Play();

        float intensity01 = Mathf.Clamp01(lastSwingIntensity);

        float targetVolume = Mathf.Lerp(
            minSwingVolume,
            maxSwingVolume,
            intensity01
        );

        // Opcjonalnie: speed też wpływa na pitch
        float speed01 = Mathf.Clamp01(lastSwingSpeed / 720f);

        float staminaMul = GetStaminaSwingMultiplier();

        float targetPitch = Mathf.Lerp(
            minSwingPitch,
            maxSwingPitch,
            Mathf.Max(intensity01, speed01) * staminaMul
        );

        swingLoopSource.volume = Mathf.Lerp(
            swingLoopSource.volume,
            targetVolume,
            Time.deltaTime * audioSmooth
        );

        swingLoopSource.pitch = Mathf.Lerp(
            swingLoopSource.pitch,
            targetPitch,
            Time.deltaTime * audioSmooth
        );
    }

    private void HandleUpgradeMenuState(bool open)
    {
        if (open)
            HardStopCombatAndAudio();
        else
            ResumeCombatAfterUpgrade();
    }

    private void HardStopCombatAndAudio()
    {
        // 1) zatrzymaj loop audio NATYCHMIAST
        if (swingLoopSource != null)
        {
            swingLoopSource.Stop();
            swingLoopSource.time = 0f;
        }

        // 2) wyłącz hitbox, żeby nie było "ciągłego ataku"
        if (weaponHitbox != null)
            weaponHitbox.enabled = false;

        // 3) reset ataku
        if (combatInputSource != null)
            attacking = false;

        // 4) wróć bronią do idle pozycji
        if (weaponPivot != null)
            weaponPivot.localRotation = weaponIdleLocalRot;
    }

    private void OnDestroy()
    {
        if (playerProg != null)
            playerProg.OnUpgradeMenuStateChanged -= HandleUpgradeMenuState;
    }

    private float GetStaminaSwingMultiplier()
    {
        if (playerProg != null && playerProg.stats != null)
        {
            float max = Mathf.Max(1f, playerProg.stats.maxStamina);
            float current = Mathf.Clamp(playerProg.currentStamina, 0f, max);
            float t = current / max;

            return Mathf.Lerp(minSwingStaminaMultiplier, 1f, t * t);
        }

        if (agent != null)
        {
            float max = Mathf.Max(1f, agent.maxStamina);
            float t = Mathf.Clamp01(agent.stamina / max);
            return Mathf.Lerp(minSwingStaminaMultiplier, 1f, t * t);
        }

        return 1f;
    }

    private void ResumeCombatAfterUpgrade()
    {
        // 1) przywróć hitbox
        if (weaponHitbox != null)
            weaponHitbox.enabled = true;

        // 2) reset stanu ataku
        attacking = false;
        lastSwing = Vector2.zero;
        lastSwingSpeed = 0f;
        lastSwingIntensity = 0f;

        // 3) reset rotacji broni
        if (weaponPivot != null)
        {
            weaponPivot.localRotation = weaponIdleLocalRot;
            lastRotation = weaponPivot.rotation;
        }

        // 4) upewnij się, że audio jest w stanie idle
        if (swingLoopSource != null)
        {
            swingLoopSource.Stop();
            swingLoopSource.time = 0f;
        }
    }

    // ===========================
    // ✅ ENHANCER-AWARE STATS API
    // ===========================

    public float GetSwingSpeedMultiplier()
    {
        float mul = baseSwingSpeedMultiplier;

        if (playerProg != null && playerProg.stats != null)
            mul *= Mathf.Max(0.1f, playerProg.stats.swingSpeed);

        if (enhancerSystem != null)
            mul = enhancerSystem.GetEffectiveValue(
                StatType.SwingSpeed,
                mul
            );

        return Mathf.Max(0.05f, mul);
    }

    public float GetDamageMultiplier()
    {
        float baseDamage = 1f;

        if (playerProg != null && playerProg.stats != null)
            baseDamage *= playerProg.stats.damage;

        if (enhancerSystem != null)
            baseDamage = enhancerSystem.GetEffectiveValue(
                StatType.Damage,
                baseDamage
            );

        return baseDamage;
    }

    public float GetCritChance()
    {
        float baseCrit = 0f;

        if (playerProg != null && playerProg.stats != null)
            baseCrit = playerProg.stats.critChance;

        if (enhancerSystem != null)
            baseCrit = enhancerSystem.GetEffectiveValue(
                StatType.CritChance,
                baseCrit
            );

        return Mathf.Clamp01(baseCrit);
    }

    public float GetLifeSteal()
    {
    float baseLS = 0f;

    if (playerProg != null && playerProg.stats != null)
        baseLS = playerProg.stats.lifeSteal;

    if (enhancerSystem != null)
        baseLS = enhancerSystem.GetEffectiveValue(
            StatType.LifeSteal,
            baseLS
        );

    return Mathf.Max(0f, baseLS);
    }
}
