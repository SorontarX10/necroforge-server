using UnityEngine;
using GrassSim.Combat;
using GrassSim.Enemies;

public class ZombieEyeEmissionController : MonoBehaviour
{
    [Header("Enemy References")]
    public EnemyCombatant enemyCombatant; // optional assignment

    [Header("Emission Settings")]
    public Color fullHealthEmissionColor = Color.green;
    public Color zeroHealthEmissionColor = Color.black;
    [Tooltip("HDR intensity at full health")]
    public float maxEmissionIntensity = 3f;
    [Tooltip("Minimum visible intensity near zero health")]
    public float minEmissionIntensity = 0f;

    private Material eyeMaterial;
    private int emissionColorID;
    private Combatant combatant;

    void Awake()
    {
        // 1) Find Combatant
        if (enemyCombatant == null)
            enemyCombatant = GetComponentInParent<EnemyCombatant>();

        if (enemyCombatant != null)
            combatant = enemyCombatant.GetComponent<Combatant>();

        if (combatant == null)
            Debug.LogWarning("[ZombieEyeEmission] Combatant not found!", this);

        // 2) Find the correct renderer/material for eyes
        Renderer[] renderers = GetComponentsInChildren<Renderer>();
        if (renderers == null || renderers.Length == 0)
        {
            Debug.LogError("[ZombieEyeEmission] No Renderer found in children!", this);
            return;
        }

        eyeMaterial = FindBestEmissionMaterial(renderers);

        if (eyeMaterial == null)
        {
            Debug.LogError("[ZombieEyeEmission] Could not determine eye material!", this);
            return;
        }

        emissionColorID = Shader.PropertyToID("_EmissionColor");

        // ensure shader uses emission
        eyeMaterial.EnableKeyword("_EMISSION");

        UpdateEmission(); // initial
    }

    void Update()
    {
        UpdateEmission();
    }

    private Material FindBestEmissionMaterial(Renderer[] renderers)
    {
        Material bestMat = null;
        float bestEmissionValue = -1f;

        foreach (Renderer r in renderers)
        {
            foreach (Material mat in r.materials)
            {
                if (mat == null)
                    continue;

                if (!mat.HasProperty("_EmissionColor"))
                    continue;

                Color baseColor = mat.GetColor("_EmissionColor");
                float intensity = baseColor.maxColorComponent;

                // pick material with highest emission base value
                if (intensity > bestEmissionValue)
                {
                    bestEmissionValue = intensity;
                    bestMat = mat;
                }
            }
        }

        return bestMat;
    }

    private void UpdateEmission()
    {
        if (eyeMaterial == null || combatant == null)
            return;

        float currentHP = combatant.currentHealth;
        float maxHP = combatant.MaxHealth > 0f ? combatant.MaxHealth : 1f;

        float t = Mathf.Clamp01(currentHP / maxHP);

        Color color = Color.Lerp(zeroHealthEmissionColor, fullHealthEmissionColor, t);
        float intensity = Mathf.Lerp(minEmissionIntensity, maxEmissionIntensity, t);

        eyeMaterial.SetColor(emissionColorID, color * intensity);
    }
}
