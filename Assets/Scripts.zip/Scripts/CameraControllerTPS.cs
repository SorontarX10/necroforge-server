using UnityEngine;

public class CameraControllerTPS : MonoBehaviour
{
    [Header("References")]
    public Transform player;     // gracz
    public Transform cameraT;    // MainCamera lub Virtual Camera

    [Header("Settings")]
    public float mouseSensitivity = 3f;
    public float distance = 5f;

    public float pivotHeightOffset = 1.7f; // wysokość pivot nad graczem

    public float pitchMin = -10f;
    public float pitchMax = 80f;

    private float yaw;
    private float pitch;

    void Start()
    {
        if (player == null || cameraT == null)
        {
            Debug.LogError("[Camera TPS] Przypisz player i cameraT!", this);
            enabled = false;
            return;
        }

        yaw = transform.eulerAngles.y;
        pitch = 10f;
    }

    void LateUpdate()
    {
        if (player == null)
            return;

        // zawsze ustaw pivot ponad graczem
        Vector3 pivotPos = player.position + Vector3.up * pivotHeightOffset;
        transform.position = pivotPos;

        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;

        yaw += mouseX;
        pitch -= mouseY;
        pitch = Mathf.Clamp(pitch, pitchMin, pitchMax);

        transform.rotation = Quaternion.Euler(pitch, yaw, 0f);

        cameraT.position = transform.position - transform.forward * distance;

        // patrzy na pivot, nie na ziemię
        cameraT.LookAt(transform.position);
    }
}
