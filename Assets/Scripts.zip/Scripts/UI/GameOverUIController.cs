using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class GameOverUIController : MonoBehaviour
{
    [Header("UI")]
    public Image background;
    public GameObject panel;

    public TMP_Text finalScoreText;
    public TMP_Text killsText;
    public TMP_Text timeText;

    public TMP_Text[] leaderboardEntries;

    [Header("Fade")]
    public float fadeDuration = 1.5f;

    private void Awake()
    {
        background.color = new Color(0, 0, 0, 0);
        panel.SetActive(false);
    }

    public void Show(GameRunStats stats)
    {
        gameObject.SetActive(true);
        panel.SetActive(true);

        finalScoreText.text = $"FINAL SCORE: {stats.finalScore}";
        killsText.text = $"Kills: {stats.kills}";
        timeText.text = $"Time Survived: {FormatTime(stats.timeSurvived)}";

        LocalLeaderboardService.SaveScore(stats.finalScore);
        RefreshLeaderboard();

        StartCoroutine(FadeIn());
    }

    private IEnumerator FadeIn()
    {
        float t = 0f;
        while (t < fadeDuration)
        {
            t += Time.unscaledDeltaTime;
            background.color = new Color(0, 0, 0, t / fadeDuration);
            yield return null;
        }
        background.color = new Color(0, 0, 0, 1);
    }

    private void RefreshLeaderboard()
    {
        var scores = LocalLeaderboardService.GetTopScores(leaderboardEntries.Length);
        for (int i = 0; i < leaderboardEntries.Length; i++)
        {
            leaderboardEntries[i].text =
                i < scores.Length ? $"{i + 1}. {scores[i]}" : $"{i + 1}. ---";
        }
    }

    private string FormatTime(float t)
    {
        int m = Mathf.FloorToInt(t / 60f);
        int s = Mathf.FloorToInt(t % 60f);
        return $"{m:00}:{s:00}";
    }
}
