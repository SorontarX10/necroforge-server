using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class StatRowUI : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private TextMeshProUGUI labelText;
    [SerializeField] private TextMeshProUGUI valueText;

    [Header("Boost Colors")]
    [SerializeField] private Color normalColor = new Color(0.85f, 0.85f, 0.85f, 1f);
    [SerializeField] private Color boostedColor = new Color(0.25f, 1f, 0.35f, 1f);

    private bool boosted;

    private void Reset()
    {
        // Spróbuj auto-podpiąć, jeśli to prefab row z 2 TMP
        var tmps = GetComponentsInChildren<TextMeshProUGUI>(true);
        if (tmps != null && tmps.Length >= 2)
        {
            labelText = tmps[0];
            valueText = tmps[1];
        }
    }

    public void SetBoosted(bool isBoosted)
    {
        if (boosted == isBoosted) return;
        boosted = isBoosted;

        var c = boosted ? boostedColor : normalColor;

        if (labelText != null) labelText.color = c;
        if (valueText != null) valueText.color = c;
    }

    public void SetInt(int v)
    {
        if (valueText != null)
            valueText.text = v.ToString();
    }

    public void SetFloat(float v, int decimals = 1)
    {
        if (valueText != null)
            valueText.text = v.ToString($"F{decimals}");
    }

    public void SetPercent(float v01)
    {
        v01 = Mathf.Clamp01(v01);
        if (valueText != null)
            valueText.text = (v01 * 100f).ToString("F1") + "%";
    }

    public void SetMultiplier(float mul)
    {
        if (valueText != null)
            valueText.text = mul.ToString("F2") + "x";
    }

    public void SetPerSecond(float v)
    {
        if (valueText != null)
            valueText.text = v.ToString("F1") + " /s";
    }

    public void SetCurrentMax(float current, float max)
    {
        if (valueText != null)
            valueText.text = $"{current:F0} / {max:F0}";
    }
}
