using System.Collections.Generic;
using UnityEngine;
using GrassSim.Core;
using GrassSim.Upgrades;

public class UpgradeSelectionUI : MonoBehaviour
{
    [Header("Refs")]
    public Canvas upgradeCanvas;        // <— WAŻNE
    public GameObject root;              // panel z kartami
    public UpgradeCardUI[] cards;
    public UpgradeStatIconLibrary iconLibrary;

    private PlayerProgressionController player;
    private CursorScript cursor;

    private void Awake()
    {
        player = FindFirstObjectByType<PlayerProgressionController>();
        if (player == null)
        {
            Debug.LogWarning("[UpgradeSelectionUI] Player not found yet, waiting...");
        }
        else
        {
            player.OnLevelUpOptionsRolled += Show;
        }

        cursor = FindFirstObjectByType<CursorScript>();
        Hide(); // ⬅️ DOMYŚLNIE UKRYTE
    }

    void Update()
    {
        if (player == null)
        {
            player = FindFirstObjectByType<PlayerProgressionController>();
            if (player != null)
                player.OnLevelUpOptionsRolled += Show;
        }
    }

    private void OnDestroy()
    {
        if (player != null)
            player.OnLevelUpOptionsRolled -= Show;
    }

    private void Show(List<UpgradeOption> options)
    {
        if (upgradeCanvas != null)
            upgradeCanvas.enabled = true;

        if (root != null)
            root.SetActive(true);

        cursor?.ShowCursor();

        for (int i = 0; i < cards.Length; i++)
        {
            if (cards[i] == null) continue;

            var opt = (options != null && i < options.Count) ? options[i] : null;
            var col = opt != null ? RarityColor(opt.rarity) : Color.gray;

            cards[i].Bind(
                opt,
                iconLibrary,
                RarityColor(opt.rarity),
                OnPick
            );
        }
    }

    private void Hide()
    {
        if (root != null)
            root.SetActive(false);

        if (upgradeCanvas != null)
            upgradeCanvas.enabled = false;
    }

    private void OnPick(UpgradeOption option)
    {
        if (option == null || player == null)
            return;

        player.ApplyUpgrade(option);
        Hide();

        cursor?.HideCursor();
    }

    private Color RarityColor(UpgradeRarity r)
    {
        return r switch
        {
            UpgradeRarity.Common     => Hex("#808080"),
            UpgradeRarity.Uncommon   => Hex("#3CB371"),
            UpgradeRarity.Rare       => Hex("#3A7BD5"),
            UpgradeRarity.Legendary  => Hex("#FFD700"), // GOLD
            UpgradeRarity.Mythic     => Hex("#8A2BE2"), // PURPLE
            _ => Color.white
        };
    }

    private Color Hex(string hex)
    {
        ColorUtility.TryParseHtmlString(hex, out var c);
        return c;
    }
}
