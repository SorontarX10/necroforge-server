using UnityEngine;
using UnityEngine.UI;
using TMPro;
using GrassSim.Upgrades;
using GrassSim.Stats;
using System;

public class UpgradeCardUI : MonoBehaviour
{
    [Header("UI")]
    public Image icon;
    public Image rarityBorder;
    public TMP_Text nameText;
    public TMP_Text descText;
    public TMP_Text valueText;
    public Button button;

    private UpgradeOption boundOption;
    private Action<UpgradeOption> onPickCallback;

    public void Bind(
        UpgradeOption option,
        UpgradeStatIconLibrary iconLibrary,
        Color rarityColor,
        Action<UpgradeOption> onPick
    )
    {
        boundOption = option;
        onPickCallback = onPick;

        // === ICON ===
        if (icon != null && iconLibrary != null)
            icon.sprite = iconLibrary.GetIcon(option.stat);

        // === RARITY ===
        if (rarityBorder != null)
            rarityBorder.color = rarityColor;

        // === TEXTS ===
        nameText.text = option.stat.ToString();
        descText.text = GetDescription(option.stat);
        valueText.text = GetValueText(option);

        // === BUTTON ===
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
        onPickCallback?.Invoke(boundOption);
    }

    // ================= HELPERS =================

    private string GetValueText(UpgradeOption option)
    {
        // procentowe staty
        if (IsPercentStat(option.stat))
            return $"+{option.value * 100f:0.#}%";

        // regeneracje – 2 miejsca po przecinku
        if (option.stat == StatType.HealthRegen || option.stat == StatType.StaminaRegen)
            return $"+{option.value:0.00}/s";

        // reszta – flat
        return $"+{option.value:0}";
    }


    private bool IsPercentStat(StatType stat)
    {
        return stat == StatType.CritChance
            || stat == StatType.CritMultiplier
            || stat == StatType.DodgeChance
            || stat == StatType.DamageReduction
            || stat == StatType.LifeSteal;
    }

    private string GetDescription(StatType stat)
    {
        return stat switch
        {
            StatType.MaxHealth => "Increases maximum health",
            StatType.HealthRegen => "Regenerates health over time",
            StatType.MaxStamina => "Increases maximum stamina",
            StatType.StaminaRegen => "Regenerates stamina over time",
            StatType.Damage => "Increases damage dealt",
            StatType.CritChance => "Increases critical hit chance",
            StatType.CritMultiplier => "Increases critical damage",
            StatType.LifeSteal => "Heals on dealing damage",
            StatType.DamageReduction => "Reduces incoming damage",
            StatType.DodgeChance => "Chance to avoid damage",
            StatType.SwingSpeed => "Increases sword attack velocity",
            StatType.Speed => "Increases velocity of the player",
            _ => ""
        };
    }
}
