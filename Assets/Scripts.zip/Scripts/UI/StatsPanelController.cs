using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

using GrassSim.Core;
using GrassSim.Stats;
using GrassSim.Enhancers;

public class StatsPanelController : MonoBehaviour
{
    [Header("Layout")]
    [SerializeField] private RectTransform panelRoot;
    [SerializeField] private RectTransform headerRect;
    [SerializeField] private RectTransform contentRect;

    [Header("Sections (Global always on; others only when expanded)")]
    [SerializeField] private GameObject globalSection;
    [SerializeField] private GameObject combatSection;
    [SerializeField] private GameObject survivalSection;

    [Header("Header UI")]
    [SerializeField] private TextMeshProUGUI titleText;
    [SerializeField] private TextMeshProUGUI chevronText;

    [Header("Game References")]
    [SerializeField] private WorldStats world;
    [SerializeField] private PlayerProgressionController player;
    [SerializeField] private WeaponController weapon;

    [Header("Global Rows")]
    [SerializeField] private StatRowUI difficultyRow;
    [SerializeField] private StatRowUI enemiesSpawnedRow;
    [SerializeField] private StatRowUI enemiesKilledRow;

    [Header("Combat Rows")]
    [SerializeField] private StatRowUI damageRow;
    [SerializeField] private StatRowUI swingSpeedRow;
    [SerializeField] private StatRowUI critChanceRow;
    [SerializeField] private StatRowUI critDamageRow;
    [SerializeField] private StatRowUI lifeStealRow;
    [SerializeField] private StatRowUI speedRow;

    [Header("Survival Rows (MAX VALUES ONLY)")]
    [SerializeField] private StatRowUI healthRow;      // MAX HEALTH
    [SerializeField] private StatRowUI staminaRow;     // MAX STAMINA
    [SerializeField] private StatRowUI healthRegenRow;
    [SerializeField] private StatRowUI staminaRegenRow;
    [SerializeField] private StatRowUI damageReductionRow;
    [SerializeField] private StatRowUI dodgeChanceRow;

    [Header("Animation")]
    [SerializeField] private float animationSpeed = 12f;
    [SerializeField] private float heightSnapEpsilon = 0.5f;

    [Header("UI Refresh Limits")]
    [SerializeField] private float statsRefreshInterval = 0.25f;

    [Header("Resolve Player")]
    [SerializeField] private float resolveRetryInterval = 0.25f;

    [Header("Sizing")]
    [Tooltip("Dodatkowy margines w px, żeby ramka nie 'ścinała' dołu.")]
    [SerializeField] private float bottomPadding = 8f;

    private bool isExpanded;
    private float collapsedHeight;
    private float targetHeight;
    private float lastStatsRefreshTime;

    private Coroutine resolveRoutine;
    private Coroutine sizeRoutine;
    private bool subscribed;
    [SerializeField] private WeaponEnhancerSystem enhancers; // optional override

    // ================= UNITY =================

    private void Awake()
    {
        collapsedHeight = headerRect != null ? headerRect.rect.height : 0f;

        SetExpandedVisual(false);
        SetSectionsExpanded(false);

        if (panelRoot != null)
            panelRoot.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, collapsedHeight);

        targetHeight = collapsedHeight;
    }

    private void OnEnable()
    {
        if (world != null)
            world.OnChanged += OnWorldChanged;

        globalSection?.SetActive(true);

        if (player == null)
            resolveRoutine = StartCoroutine(ResolvePlayerRoutine());
        else
            AttachToPlayer(player);

        RefreshWorldStats();
    }

    private void OnDisable()
    {
        if (world != null)
            world.OnChanged -= OnWorldChanged;

        if (resolveRoutine != null)
        {
            StopCoroutine(resolveRoutine);
            resolveRoutine = null;
        }

        if (sizeRoutine != null)
        {
            StopCoroutine(sizeRoutine);
            sizeRoutine = null;
        }

        DetachFromPlayer();
    }

    private void Update()
    {
        HandleInput();
        AnimateHeightIfNeeded();
    }

    // ================= PLAYER RESOLVE =================

    private IEnumerator ResolvePlayerRoutine()
    {
        while (player == null)
        {
            player = FindFirstObjectByType<PlayerProgressionController>();
            if (player != null)
                break;

            yield return new WaitForSecondsRealtime(resolveRetryInterval);
        }

        AttachToPlayer(player);
    }

    private void AttachToPlayer(PlayerProgressionController p)
    {
        if (p == null) return;

        DetachFromPlayer();

        player = p;

        if (weapon == null)
            weapon = player.GetComponentInChildren<WeaponController>(true);

        if (enhancers == null)
        {
            if (weapon != null)
                enhancers = weapon.GetComponentInChildren<WeaponEnhancerSystem>(true);

            if (enhancers == null)
                enhancers = player.GetComponentInChildren<WeaponEnhancerSystem>(true);
        }

        player.OnStatsChanged += OnPlayerStatsChanged;

        if (enhancers != null)
            enhancers.OnChanged += OnEnhancersChanged;

        subscribed = true;

        if (isExpanded)
        {
            RefreshAllExpanded();
            RecalculateExpandedHeightOnce();
        }
        else
        {
            RefreshWorldStats();
        }
    }

    private void DetachFromPlayer()
    {
        if (!subscribed) return;

        if (player != null)
            player.OnStatsChanged -= OnPlayerStatsChanged;

        if (enhancers != null)
            enhancers.OnChanged -= OnEnhancersChanged;

        subscribed = false;
        player = null;
        weapon = null;
        enhancers = null;
    }

    private void OnEnhancersChanged()
    {
        if (!isExpanded) return;
        RefreshCombatAndSurvivalStats();
    }

    // ================= INPUT =================

    private void HandleInput()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
            Expand();

        if (Input.GetKeyUp(KeyCode.Tab))
            Collapse();
    }

    // ================= EXPAND / COLLAPSE =================

    private void Expand()
    {
        if (isExpanded) return;
        isExpanded = true;

        SetSectionsExpanded(true);
        SetExpandedVisual(true);

        RefreshAllExpanded();

        // KLUCZ: wysokość liczymy po tym jak TMP/Layout policzy preferred sizes
        ScheduleRecalcExpandedHeight();
    }

    private void Collapse()
    {
        if (!isExpanded) return;
        isExpanded = false;

        SetSectionsExpanded(false);
        targetHeight = collapsedHeight;

        SetExpandedVisual(false);
        RefreshWorldStats();
    }

    private void SetSectionsExpanded(bool expanded)
    {
        globalSection?.SetActive(true);
        combatSection?.SetActive(expanded);
        survivalSection?.SetActive(expanded);
    }

    private void SetExpandedVisual(bool expanded)
    {
        if (titleText != null) titleText.text = "STATS";
        if (chevronText != null) chevronText.text = expanded ? "▼" : "▶";
    }

    // ================= ANIMATION =================

    private void AnimateHeightIfNeeded()
    {
        if (panelRoot == null) return;

        float current = panelRoot.rect.height;
        float diff = Mathf.Abs(current - targetHeight);

        if (diff <= heightSnapEpsilon)
        {
            if (diff > 0.01f)
                panelRoot.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, targetHeight);
            return;
        }

        float next = Mathf.Lerp(current, targetHeight, Time.unscaledDeltaTime * animationSpeed);
        panelRoot.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, next);
    }

    // ================= SIZING (FIX) =================

    private void ScheduleRecalcExpandedHeight()
    {
        if (!isExpanded) return;

        if (sizeRoutine != null)
            StopCoroutine(sizeRoutine);

        sizeRoutine = StartCoroutine(RecalcExpandedHeightDeferred());
    }

    private IEnumerator RecalcExpandedHeightDeferred()
    {
        // 1) poczekaj 1 klatkę, żeby TMP przeliczył mesh / preferred size
        yield return null;
        // 2) i jeszcze do końca klatki (pewność dla LayoutGroup)
        yield return new WaitForEndOfFrame();

        if (!isExpanded || headerRect == null || contentRect == null)
            yield break;

        // Rebuild layout tylko contentu (lekko) — bez Canvas.ForceUpdateCanvases
        LayoutRebuilder.ForceRebuildLayoutImmediate(contentRect);

        // Najważniejsze: używamy PreferredHeight, nie rect.height
        float preferred = LayoutUtility.GetPreferredHeight(contentRect);

        targetHeight = headerRect.rect.height + preferred + bottomPadding;
    }

    // ================= EVENTS =================

    private void OnWorldChanged()
    {
        RefreshWorldStats();
    }

    private void OnPlayerStatsChanged()
    {
        if (!isExpanded) return;

        if (Time.unscaledTime - lastStatsRefreshTime < statsRefreshInterval)
            return;

        lastStatsRefreshTime = Time.unscaledTime;

        RefreshCombatAndSurvivalStats();

        // jeśli teksty zmieniły szerokości/wysokości, przelicz rozmiar jeszcze raz
        ScheduleRecalcExpandedHeight();
    }

    // ================= REFRESH =================

    private void RefreshAllExpanded()
    {
        RefreshWorldStats();
        RefreshCombatAndSurvivalStats();
    }

    private void RefreshWorldStats()
    {
        if (world == null) return;

        difficultyRow?.SetInt(world.difficulty);
        enemiesSpawnedRow?.SetInt(world.enemiesSpawned);
        enemiesKilledRow?.SetInt(world.enemiesKilled);
    }

    private void RefreshCombatAndSurvivalStats()
    {
        if (player == null || player.stats == null)
            return;

        var s = player.stats;
        var e = enhancers;

        // ===========================
        // COMBAT – BASE
        // ===========================
        float baseDamage = s.damage;
        float baseCritChance = s.critChance;
        float baseCritMult = s.critMultiplier;
        float baseLifeSteal = s.lifeSteal;

        // ===========================
        // COMBAT – EFFECTIVE
        // ===========================
        float dmg = baseDamage;
        float critChance = baseCritChance;
        float critMult = baseCritMult;
        float lifeSteal = baseLifeSteal;

        if (e != null)
        {
            dmg = e.GetEffectiveValue(StatType.Damage, dmg);
            critChance = e.GetEffectiveValue(StatType.CritChance, critChance);
            critMult = e.GetEffectiveValue(StatType.CritMultiplier, critMult);
            lifeSteal = e.GetEffectiveValue(StatType.LifeSteal, lifeSteal);
        }

        damageRow?.SetFloat(dmg);
        critChanceRow?.SetPercent(critChance);
        critDamageRow?.SetPercent(Mathf.Max(0f, critMult - 1f));
        lifeStealRow?.SetPercent(lifeSteal);

        // ===========================
        // SWING SPEED (FROM WEAPON)
        // ===========================
        float swingMul = 1f;

        if (weapon == null)
            weapon = player.GetComponentInChildren<WeaponController>(true);

        if (weapon != null)
            swingMul = weapon.GetSwingSpeedMultiplier();

        swingSpeedRow?.SetMultiplier(swingMul);

        // ===========================
        // SURVIVAL – BASE
        // ===========================
        float baseMaxHp = s.maxHealth;
        float baseMaxStam = s.maxStamina;
        float baseHpRegen = s.healthRegen;
        float baseStaRegen = s.staminaRegen;
        float baseDmgRed = s.damageReduction;
        float baseDodge = s.dodgeChance;

        // ===========================
        // SURVIVAL – EFFECTIVE
        // ===========================
        float maxHp = baseMaxHp;
        float maxStam = baseMaxStam;
        float hpRegen = baseHpRegen;
        float staRegen = baseStaRegen;
        float dmgRed = baseDmgRed;
        float dodge = baseDodge;

        if (e != null)
        {
            maxHp = e.GetEffectiveValue(StatType.MaxHealth, maxHp);
            maxStam = e.GetEffectiveValue(StatType.MaxStamina, maxStam);
            hpRegen = e.GetEffectiveValue(StatType.HealthRegen, hpRegen);
            staRegen = e.GetEffectiveValue(StatType.StaminaRegen, staRegen);
            dmgRed = e.GetEffectiveValue(StatType.DamageReduction, dmgRed);
            dodge = e.GetEffectiveValue(StatType.DodgeChance, dodge);
        }

        healthRow?.SetFloat(maxHp);
        staminaRow?.SetFloat(maxStam);
        healthRegenRow?.SetPerSecond(hpRegen);
        staminaRegenRow?.SetPerSecond(staRegen);
        damageReductionRow?.SetPercent(dmgRed);
        dodgeChanceRow?.SetPercent(dodge);

        // ===========================
        // BOOST HIGHLIGHT (ONLY TRUTH)
        // ===========================
        bool Boosted(float baseVal, float effVal)
            => !Mathf.Approximately(baseVal, effVal);

        damageRow?.SetBoosted(Boosted(baseDamage, dmg));
        critChanceRow?.SetBoosted(Boosted(baseCritChance, critChance));
        critDamageRow?.SetBoosted(Boosted(baseCritMult, critMult));
        lifeStealRow?.SetBoosted(Boosted(baseLifeSteal, lifeSteal));

        swingSpeedRow?.SetBoosted(
            weapon != null && !Mathf.Approximately(1f, swingMul)
        );

        healthRow?.SetBoosted(Boosted(baseMaxHp, maxHp));
        staminaRow?.SetBoosted(Boosted(baseMaxStam, maxStam));
        healthRegenRow?.SetBoosted(Boosted(baseHpRegen, hpRegen));
        staminaRegenRow?.SetBoosted(Boosted(baseStaRegen, staRegen));
        damageReductionRow?.SetBoosted(Boosted(baseDmgRed, dmgRed));
        dodgeChanceRow?.SetBoosted(Boosted(baseDodge, dodge));
    }

    private void RecalculateExpandedHeightOnce()
    {
        if (panelRoot == null)
            return;

        // Zakładamy, że masz VerticalLayoutGroup / ContentSizeFitter
        LayoutRebuilder.ForceRebuildLayoutImmediate(panelRoot);
    }
}
