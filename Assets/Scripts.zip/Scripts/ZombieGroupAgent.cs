using UnityEngine;

public class ZombieGroupAgent : MonoBehaviour
{
    [Header("Grouping")]
    public float groupRadius = 6f;
    public float cohesionStrength = 1f;

    [Header("Update")]
    public float updateInterval = 0.5f;

    [Header("Layers")]
    public LayerMask zombieLayer;

    Vector3 cachedGroupCenter;
    float nextUpdateTime;
    bool hasGroup;

    void Awake()
    {
        nextUpdateTime = Random.Range(0f, updateInterval);
    }

    void Update()
    {
        if (Time.time < nextUpdateTime)
            return;

        nextUpdateTime = Time.time + updateInterval;
        RecalculateGroup();
    }

    void RecalculateGroup()
    {
        Collider[] hits = Physics.OverlapSphere(
            transform.position,
            groupRadius,
            zombieLayer,
            QueryTriggerInteraction.Ignore
        );

        Vector3 sum = Vector3.zero;
        int count = 0;

        foreach (var h in hits)
        {
            if (!h)
                continue;

            Transform t = h.transform;

            // ignoruj siebie
            if (t == transform)
                continue;

            // ignoruj własne childy (ręce, hitboxy)
            if (t.IsChildOf(transform))
                continue;

            sum += t.position;
            count++;
        }

        if (count > 0)
        {
            cachedGroupCenter = sum / count;
            hasGroup = true;
        }
        else
        {
            hasGroup = false;
        }
    }

    /// <summary>
    /// Zwraca wektor spójności grupy (do środka stada)
    /// </summary>
    public Vector3 GetCohesionDirection()
    {
        if (!hasGroup)
            return Vector3.zero;

        Vector3 dir = cachedGroupCenter - transform.position;
        dir.y = 0f;

        if (dir.sqrMagnitude < 0.01f)
            return Vector3.zero;

        return dir.normalized * cohesionStrength;
    }

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, groupRadius);

        if (hasGroup)
        {
            Gizmos.color = Color.blue;
            Gizmos.DrawSphere(cachedGroupCenter, 0.15f);
        }
    }
#endif
}
