using UnityEngine;
using GrassSim.Core;

namespace GrassSim.Combat
{
    /// <summary>
    /// Combatant = runtime HP container for enemies.
    /// For player: acts as a proxy to PlayerProgressionController.
    /// </summary>
    public class Combatant : MonoBehaviour
    {
        [Header("Enemy runtime HP")]
        [SerializeField] public float currentHealth;
        [SerializeField] private float maxHealth;

        private bool isDead;
        private bool initialized;

        private PlayerProgressionController player; // 🔥 proxy

        public bool IsDead =>
            player != null ? player.IsDead : isDead;

        public float CurrentHealth =>
            player != null ? player.CurrentHealth : currentHealth;

        public float MaxHealth =>
            player != null ? player.MaxHealth : maxHealth;

        private void Awake()
        {
            player = GetComponent<PlayerProgressionController>();

            if (player != null)
            {
                // gracz NIE używa lokalnego HP
                return;
            }

            if (!initialized)
            {
                currentHealth = Mathf.Max(1f, currentHealth);
                maxHealth = Mathf.Max(currentHealth, maxHealth);
                isDead = false;
                initialized = true;
            }
        }

        /// <summary>
        /// Enemy-only init
        /// </summary>
        public void Initialize(float enemyMaxHealth)
        {
            if (player != null)
                return;

            maxHealth = Mathf.Max(1f, enemyMaxHealth);
            currentHealth = maxHealth;
            isDead = false;
            initialized = true;
        }

        public void TakeDamage(float damage, Transform atacker = null)
        {
            if (damage <= 0f || IsDead)
                return;

            if (player != null)
            {
                player.TakeDamage(damage);
                if (player.IsDead)
                    Die();
                return;
            }

            currentHealth -= damage;
            if (currentHealth <= 0f)
            {
                currentHealth = 0f;
                Die();
            }
        }

        public void Heal(float amount)
        {
            if (amount <= 0f || IsDead)
                return;

            if (player != null)
            {
                player.Heal(amount);
                return;
            }

            currentHealth = Mathf.Min(maxHealth, currentHealth + amount);
        }

        protected virtual void Die()
        {
            if (isDead)
                return;

            isDead = true;
            SendMessage("OnCombatantDied", SendMessageOptions.DontRequireReceiver);
        }
    }
}
