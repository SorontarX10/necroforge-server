using UnityEngine;
using GrassSim.Core;
using GrassSim.Combat;

namespace GrassSim.Combat
{
    public class MeleeDamageApplier : MonoBehaviour
    {
        public float baseDamageFallback = 10f;

        public DamageResult ComputeDamage(PlayerProgressionController attacker)
        {
            float dmg = baseDamageFallback;
            bool isCrit = false;

            if (attacker != null && attacker.stats != null)
            {
                dmg = attacker.stats.damage;
                isCrit = Random.value < attacker.stats.critChance;
                if (isCrit)
                    dmg *= attacker.stats.critMultiplier;
            }

            float heal = 0f;
            if (attacker != null && attacker.stats != null && attacker.stats.lifeSteal > 0f)
                heal = dmg * attacker.stats.lifeSteal;

            return new DamageResult
            {
                finalDamage = dmg,
                isCrit = isCrit,
                lifestealHeal = heal
            };
        }

        public float ApplyTargetMitigation(float rawDamage, PlayerProgressionController target)
        {
            if (target == null || target.stats == null)
                return rawDamage;

            // Dodge check
            if (target.stats.dodgeChance > 0f && Random.value < target.stats.dodgeChance)
                return 0f;

            float mitigated = rawDamage * (1f - target.stats.damageReduction);
            return Mathf.Max(0f, mitigated);
        }
    }
}
