using UnityEngine;

public class FloatingTextSystem : MonoBehaviour
{
    public static FloatingTextSystem Instance;

    public FloatingText prefab;

    [Header("Canvas")]
    public float canvasScale = 0.01f;
    public int sortingOrder = 200;

    private Canvas canvas;
    private Camera cam;

    void Awake()
    {
        Instance = this;
        cam = Camera.main;

        GameObject go = new GameObject("FloatingTextCanvas");
        canvas = go.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.WorldSpace;
        canvas.sortingOrder = sortingOrder;
        canvas.worldCamera = cam;

        go.transform.SetParent(transform, false);
        go.transform.localScale = Vector3.one * canvasScale;
    }

    public void Spawn(Vector3 worldPos, float value, Color color, float fontSize = 36f)
    {
        if (prefab == null) return;

        var ft = Instantiate(prefab, canvas.transform);
        ft.transform.position = worldPos;

        string txt = value.ToString("0.##");
        ft.Init(cam, txt, color, fontSize);
    }

    public void SpawnText(Vector3 worldPos, string value, Color color, float fontSize = 36f)
    {
        if (prefab == null) return;

        var ft = Instantiate(prefab, canvas.transform);
        ft.transform.position = worldPos;

        ft.Init(cam, value, color, fontSize);
    }
}
