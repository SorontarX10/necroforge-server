using System;
using System.Collections.Generic;
using UnityEngine;
using GrassSim.Stats;

namespace GrassSim.Enhancers
{
    public class WeaponEnhancerSystem : MonoBehaviour
    {
        private readonly List<ActiveEnhancer> active = new();

        public event Action OnChanged;
        public IReadOnlyList<ActiveEnhancer> Active => active;

        private void Update()
        {
            bool changed = false;
            float dt = Time.deltaTime;

            for (int i = active.Count - 1; i >= 0; i--)
            {
                var enhancer = active[i];

                if (enhancer == null)
                {
                    active.RemoveAt(i);
                    changed = true;
                    continue;
                }

                enhancer.Tick(dt);

                if (enhancer.IsExpired)
                {
                    active.RemoveAt(i);
                    changed = true;
                }
            }

            if (changed)
                RaiseChanged();
        }

        // ===========================
        // ➕ ADD / REFRESH
        // ===========================

        public void AddEnhancer(EnhancerDefinition def)
        {
            if (def == null)
                return;

            var existing = active.Find(e => e.Definition == def);

            if (existing != null)
            {
                // ⏱️ dokładamy czas (NIE stack)
                existing.RefreshDuration();
            }
            else
            {
                active.Add(new ActiveEnhancer(def));
            }

            RaiseChanged();
        }

        // ===========================
        // 🔢 FINAL STAT VALUE
        // ===========================
        // (base + additive) * multiplicative
        public float GetEffectiveValue(StatType stat, float baseValue)
        {
            float additive = 0f;
            float multiplicative = 1f;

            foreach (var enhancer in active)
            {
                float strength = enhancer.GetStrength01();

                foreach (var effect in enhancer.Definition.statEffects)
                {
                    if (effect.stat != stat)
                        continue;

                    float value = effect.maxBonus * strength;

                    switch (effect.mathMode)
                    {
                        case EnhancerMathMode.Additive:
                            additive += value;
                            break;

                        case EnhancerMathMode.Multiplicative:
                            multiplicative *= 1f + value;
                            break;

                        case EnhancerMathMode.AdditiveThenMultiplicative:
                            additive += value;
                            multiplicative *= 1f + value;
                            break;
                    }
                }
            }

            return (baseValue + additive) * multiplicative;
        }

        private void RaiseChanged()
        {
            OnChanged?.Invoke();
        }
    }
}
