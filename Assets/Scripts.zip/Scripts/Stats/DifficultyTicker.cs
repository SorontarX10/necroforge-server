using UnityEngine;
using GrassSim.Stats;

public class DifficultyTicker : MonoBehaviour
{
    [Header("Difficulty scaling")]
    [Tooltip("Co ile sekund zwiększać difficulty")]
    public float tickInterval = 10f;

    [Tooltip("Ile dodać difficulty za tick")]
    public int difficultyStep = 1;

    private float timer;

    private void Update()
    {
        timer += Time.deltaTime;

        if (timer >= tickInterval)
        {
            timer -= tickInterval;
            Tick();
        }
    }

    private void Tick()
    {
        if (WorldStats.Instance == null)
            return;

        WorldStats.Instance.difficulty += difficultyStep;
        WorldStats.Instance.NotifyChanged();
    }
}
