using UnityEngine;
using System.Linq;

public static class LocalLeaderboardService
{
    private const string KEY = "LOCAL_SCORES";

    public static void SaveScore(int score)
    {
        var scores = GetAllScores().ToList();
        scores.Add(score);
        scores = scores.OrderByDescending(s => s).Take(10).ToList();

        PlayerPrefs.SetString(KEY, string.Join(",", scores));
        PlayerPrefs.Save();
    }

    public static int[] GetTopScores(int count)
    {
        return GetAllScores().Take(count).ToArray();
    }

    private static int[] GetAllScores()
    {
        if (!PlayerPrefs.HasKey(KEY))
            return new int[0];

        return PlayerPrefs.GetString(KEY)
            .Split(',')
            .Select(int.Parse)
            .ToArray();
    }
}
