using UnityEngine;
using GrassSim.Stats;

public static class DifficultyContext
{
    public static int Difficulty
    {
        get
        {
            if (WorldStats.Instance == null)
                return 1;
            return Mathf.Max(1, WorldStats.Instance.difficulty);
        }
    }

    // --- Multipliers ---

    public static float EnemyHealthMultiplier =>
        1f + 0.10f * (Difficulty - 1);

    public static float EnemyDamageMultiplier =>
        1f + 0.08f * (Difficulty - 1);

    public static float EnemyAttackSpeedMultiplier =>
        1f + 0.06f * (Difficulty - 1);
    
    public static float ExpMultiplier =>
        1f + 0.15f * (Difficulty - 1);

    public static float EnemyDetectionRangeMultiplier =>
        1f + 0.07f * (Difficulty - 1);

    // Spawn cap scaling
    public static int ScaleSpawnCap(int baseCap)
    {
        return Mathf.RoundToInt(baseCap * (1f + 0.12f * (Difficulty - 1)));
    }
}
