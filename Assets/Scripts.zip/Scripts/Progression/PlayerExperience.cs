using System;
using UnityEngine;

namespace GrassSim.Progression
{
    [Serializable]
    public class PlayerExperience
    {
        public int level = 1;
        public int exp = 0;
        public int expToNext = 100;

        public float expGrowth = 1.25f;

        public bool AddExp(int amount)
        {
            if (amount <= 0) return false;

            exp += amount;

            bool leveled = false;
            while (exp >= expToNext)
            {
                exp -= expToNext;
                level++;
                expToNext = Mathf.Max(1, Mathf.RoundToInt(expToNext * expGrowth));
                leveled = true;
            }

            return leveled;
        }
    }
}
