using UnityEngine;
using System.Linq;

public class ZombiePerception : MonoBehaviour
{
    public float viewRadius = 10f;
    public float viewAngle = 120f;
    public LayerMask obstacleMask;

    public Transform VisibleEnemy { get; private set; }
    public Transform VisibleZombie { get; private set; }

    void Update()
    {
        VisibleEnemy = FindVisibleTarget(new[] { "Player", "Enemy" });
        VisibleZombie = FindVisibleTarget(new[] { "Zombie" }, excludeSelf: true);
    }

    Transform FindVisibleTarget(string[] tags, bool excludeSelf = false)
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, viewRadius);

        float bestDist = float.MaxValue;
        Transform best = null;

        foreach (var hit in hits)
        {
            if (!tags.Contains(hit.tag))
                continue;

            if (excludeSelf && hit.transform == transform)
                continue;

            Vector3 dir = hit.transform.position - transform.position;
            float angle = Vector3.Angle(transform.forward, dir);

            if (angle > viewAngle * 0.5f)
                continue;

            if (Physics.Raycast(transform.position + Vector3.up * 0.5f,
                                 dir.normalized,
                                 dir.magnitude,
                                 obstacleMask))
                continue;

            float d = dir.magnitude;
            if (d < bestDist)
            {
                bestDist = d;
                best = hit.transform;
            }
        }

        return best;
    }
}
