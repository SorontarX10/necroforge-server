using UnityEngine;
using UnityEngine.UI;
using GrassSim.Combat;
using GrassSim.Enemies;

public class EnemyHealthBarBinder : MonoBehaviour
{
    [Header("Screen UI Prefab")]
    public GameObject healthBarPrefab;

    private GameObject instance;
    private ScreenSpaceWorldUI follower;
    private Image fillImage;

    private Combatant combatant;
    private EnemyCombatant enemyCombatant;

    void Awake()
    {
        combatant = GetComponentInParent<Combatant>();
        enemyCombatant = GetComponentInParent<EnemyCombatant>();

        if (combatant == null || enemyCombatant == null || healthBarPrefab == null)
        {
            enabled = false;
            return;
        }
    }

    void Start()
    {
        instance = Instantiate(healthBarPrefab);
        follower = instance.GetComponent<ScreenSpaceWorldUI>();
        fillImage = instance.GetComponentInChildren<Image>();

        if (follower == null || fillImage == null)
        {
            Debug.LogError("[EnemyHealthBarBinder] Prefab missing components.", instance);
            return;
        }

        follower.target = transform;
        follower.worldOffset = Vector3.up * GetHealthbarOffset();

        // kolor paska (opcjonalny)
        fillImage.color = Color.red;
    }

    void Update()
    {
        if (combatant == null || fillImage == null)
            return;

        float maxHp = enemyCombatant.stats.maxHealth;
        if (maxHp > 0f)
            fillImage.fillAmount = Mathf.Clamp01(combatant.CurrentHealth / maxHp);
    }

    private float GetHealthbarOffset()
    {
        var cap = GetComponentInParent<CapsuleCollider>();
        if (cap != null) return cap.height + 0.2f;

        var cc = GetComponentInParent<CharacterController>();
        if (cc != null) return cc.height + 0.2f;

        var rend = GetComponentInChildren<Renderer>();
        if (rend != null) return rend.bounds.size.y + 0.2f;

        return 2f;
    }
}
