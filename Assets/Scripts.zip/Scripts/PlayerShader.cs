using UnityEngine;

public class PlayerShader : MonoBehaviour
{
    public Renderer targetRenderer;

    private static readonly int FrontWS_ID = Shader.PropertyToID("_FrontWS");
    private MaterialPropertyBlock mpb;

    void Awake()
    {
        if (targetRenderer == null)
            targetRenderer = GetComponentInChildren<Renderer>();

        mpb = new MaterialPropertyBlock();
    }

    void LateUpdate()
    {
        if (targetRenderer == null) return;

        targetRenderer.GetPropertyBlock(mpb);

        // jeśli shader chce view direction: kierunek od obiektu do kamery:
        Vector3 viewDirWS = Vector3.zero;

        if (Camera.main != null)
        {
            viewDirWS = (Camera.main.transform.position - transform.position).normalized;
        }
        else
        {
            // fallback: forward obiektu
            viewDirWS = transform.forward;
        }

        mpb.SetVector(FrontWS_ID, viewDirWS);
        targetRenderer.SetPropertyBlock(mpb);
    }
}
