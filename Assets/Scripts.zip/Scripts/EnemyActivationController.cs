using System.Collections.Generic;
using UnityEngine;
using GrassSim.Combat;
using GrassSim.Enemies;

namespace GrassSim.AI
{
    public class EnemyActivationController : MonoBehaviour
    {
        public static EnemyActivationController Instance { get; private set; }

        [Header("Activation")]
        public float activeDistance = 50f;
        public int maxActiveEnemies = 30;

        [Header("Enemy Prefabs")]
        public List<GameObject> enemyPrefabs;

        [Header("Ground Settings")]
        public LayerMask groundMask;
        public float spawnRayHeight = 10f;
        public float spawnYOffset = 0.5f;

        [HideInInspector]
        public Vector3 playerPosition;

        private readonly Dictionary<int, GameObject> active = new();

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        void Update()
        {
            if (!ChunkedProceduralLevelGenerator.WorldReady)
                return;

            var sim = EnemySimulationManager.Instance;
            if (sim == null)
                return;

            CleanupDestroyed();

            // zapewnij globalną populację
            sim.EnsurePopulation(playerPosition);
            sim.RecycleFarEnemies(playerPosition);

            float maxD2 = activeDistance * activeDistance;

            // 1️⃣ znajdź enemy w zasięgu
            List<EnemySimState> nearby = new();

            foreach (var s in sim.GetAll())
            {
                Vector3 pos = GetEnemyWorldPosition(s);
                Vector3 d = pos - playerPosition;
                d.y = 0f;

                if (d.sqrMagnitude <= maxD2)
                    nearby.Add(s);
            }

            // 2️⃣ sortuj po dystansie
            nearby.Sort((a, b) =>
            {
                float da = (GetEnemyWorldPosition(a) - playerPosition).sqrMagnitude;
                float db = (GetEnemyWorldPosition(b) - playerPosition).sqrMagnitude;
                return da.CompareTo(db);
            });

            int currentMaxEnemies = DifficultyContext.ScaleSpawnCap(maxActiveEnemies);

            int allowed = Mathf.Min(currentMaxEnemies, nearby.Count);

            // 3️⃣ spawn brakujących
            for (int i = 0; i < allowed; i++)
            {
                var s = nearby[i];
                if (!active.ContainsKey(s.id))
                    SpawnGO(s);
            }

            // 4️⃣ despawn tych, co wyszli z zasięgu
            List<int> toRemove = new();

            foreach (var kv in active)
            {
                var go = kv.Value;
                if (go == null)
                {
                    toRemove.Add(kv.Key);
                    continue;
                }

                Vector3 d = go.transform.position - playerPosition;
                d.y = 0f;

                if (d.sqrMagnitude > maxD2)
                    toRemove.Add(kv.Key);
            }

            foreach (int id in toRemove)
                DespawnGO(id);
        }

        // ================= SPAWN / DESPAWN =================

        private void SpawnGO(EnemySimState s)
        {
            if (enemyPrefabs == null || enemyPrefabs.Count == 0)
                return;

            if (s.prefabIndex < 0 || s.prefabIndex >= enemyPrefabs.Count)
                return;

            var type = EnemySimulationManager.Instance.enemyTypes[s.prefabIndex];
            if (type == null || type.prefab == null)
                return;

            // Wyznacz pozycję spawnowania
            Vector3 spawnPos = s.position + Vector3.up * spawnYOffset;

            // Użyj raycasta o stałej wysokości, żeby znaleźć ground
            Ray ray = new Ray(s.position + Vector3.up * spawnRayHeight, Vector3.down);
            if (Physics.Raycast(ray, out RaycastHit hit, spawnRayHeight + 1f, groundMask))
            {
                spawnPos = hit.point + Vector3.up * spawnYOffset;
            }

            GameObject go = Instantiate(type.prefab, spawnPos, Quaternion.identity);

            // Combatant initialization
            Combatant combatant = go.GetComponent<Combatant>();
            EnemyCombatant enemyCombatant = go.GetComponent<EnemyCombatant>();

            if (combatant != null && enemyCombatant != null && enemyCombatant.stats != null)
            {
                combatant.Initialize(enemyCombatant.stats.maxHealth);
                enemyCombatant.simId = s.id;
            }
            else
            {
                Debug.LogWarning(
                    "[EnemyActivation] Enemy spawned WITHOUT Combatant init!",
                    go
                );
            }

            active.Add(s.id, go);
        }

        private void DespawnGO(int id)
        {
            if (!active.TryGetValue(id, out var go))
                return;

            active.Remove(id);

            if (go != null)
                Destroy(go);
        }

        public void OnEnemyKilled(int simId)
        {
            DespawnGO(simId);

            var sim = EnemySimulationManager.Instance;
            if (sim != null)
                sim.RemoveEnemy(simId);
            
            // 🔥 GLOBAL STAT
            if (GrassSim.Stats.WorldStats.Instance != null)
                GrassSim.Stats.WorldStats.Instance.AddEnemyKilled();
        }

        // ================= HELPERS =================

        private Vector3 GetEnemyWorldPosition(EnemySimState s)
        {
            if (!active.TryGetValue(s.id, out var go) || go == null)
            {
                active.Remove(s.id);
                return s.position;
            }

            return go.transform.position;
        }

        private void CleanupDestroyed()
        {
            var dead = new List<int>();

            foreach (var kv in active)
            {
                if (kv.Value == null)
                    dead.Add(kv.Key);
            }

            foreach (int id in dead)
                active.Remove(id);
        }
    }
}
