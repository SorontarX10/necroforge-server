using UnityEngine;

[RequireComponent(typeof(CanvasGroup))]
public class HealthBarFogFade : MonoBehaviour
{
    [Header("Fade distances")]
    [SerializeField] private float visibleDistance = 20f;
    [SerializeField] private float fadeOutDistance = 40f;

    private CanvasGroup canvasGroup;
    private Transform player;
    private WorldHealthBar worldBar;

    private bool loggedInit;

    void Awake()
    {
        canvasGroup = GetComponent<CanvasGroup>();
        worldBar = GetComponent<WorldHealthBar>();

        // startowo widoczne, żebyś od razu widział czy w ogóle działa
        canvasGroup.alpha = 1f;
    }

    void Start()
    {
        var playerGO = GameObject.FindGameObjectWithTag("Player");
        if (playerGO == null)
        {
            Debug.LogError("[HealthBarFogFade] Player tag not found in scene!");
            enabled = false;
            return;
        }

        player = playerGO.transform;

        if (worldBar == null)
        {
            Debug.LogError("[HealthBarFogFade] Missing WorldHealthBar on this object!");
            enabled = false;
            return;
        }

        if (worldBar.target == null)
        {
            Debug.LogError("[HealthBarFogFade] WorldHealthBar.target is NULL (binder didn't assign?).");
            enabled = false;
            return;
        }

        if (!loggedInit)
        {
            Debug.Log($"[HealthBarFogFade] OK init on {name}. target={worldBar.target.name}, player={player.name}, hasCanvasGroup={canvasGroup != null}");
            loggedInit = true;
        }
    }

    void LateUpdate()
    {
        if (player == null || worldBar == null || worldBar.target == null)
            return;

        // Player healthbar zawsze 1
        if (worldBar.target.CompareTag("Player"))
        {
            canvasGroup.alpha = 1f;
            return;
        }

        Vector3 a = worldBar.target.position; a.y = 0f;
        Vector3 b = player.position;          b.y = 0f;

        float dist = Vector3.Distance(a, b);

        float alpha;
        if (dist <= visibleDistance) alpha = 1f;
        else if (dist >= fadeOutDistance) alpha = 0f;
        else
        {
            float t = Mathf.InverseLerp(visibleDistance, fadeOutDistance, dist);
            alpha = 1f - t;
        }

        canvasGroup.alpha = alpha;
    }
}
