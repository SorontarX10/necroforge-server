using UnityEngine;

public class ZombieDifficultyDetectionScaler : MonoBehaviour
{
    public float baseDetectionRadius;

    void Awake()
    {
        var ai = GetComponent<ZombieAI>();
        if (!ai)
            return;

        baseDetectionRadius = ai.detectionRadius;

        int diff = DifficultyContext.Difficulty;

        // +10% radius per difficulty
        ai.detectionRadius = baseDetectionRadius * (1f + 0.10f * (diff - 1));
    }
}
