using UnityEngine;

public class DistanceCuller : MonoBehaviour
{
    [Tooltip("Fallback jeśli generator nie zostanie znaleziony.")]
    [SerializeField] float fallbackCullDistance = 50f;

    Transform player;
    float sqrDist;

    Renderer[] renderers;
    Collider[] colliders;

    bool lastVisible = true;

    void Awake()
    {
        renderers = GetComponentsInChildren<Renderer>(true);
        colliders = GetComponentsInChildren<Collider>(true);
    }

    void Start()
    {
        var gen = Object.FindAnyObjectByType<ChunkedProceduralLevelGenerator>();

        float dist = gen != null
            ? gen.treeCullDistance
            : fallbackCullDistance;

        sqrDist = dist * dist;

        player = GameObject.FindGameObjectWithTag("Player")?.transform;
    }

    void Update()
    {
        if (player == null)
        {
            player = GameObject.FindGameObjectWithTag("Player")?.transform;
            if (player == null) return;
        }

        bool visible =
            (transform.position - player.position).sqrMagnitude <= sqrDist;

        if (visible == lastVisible)
            return;

        lastVisible = visible;

        for (int i = 0; i < renderers.Length; i++)
            if (renderers[i] != null)
                renderers[i].enabled = visible;

        for (int i = 0; i < colliders.Length; i++)
            if (colliders[i] != null)
                colliders[i].enabled = visible;
    }
}
