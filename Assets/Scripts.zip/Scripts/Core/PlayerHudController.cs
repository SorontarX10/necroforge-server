using UnityEngine;
using UnityEngine.UI;
using TMPro;
using GrassSim.Core;
using System.Collections;

public class PlayerHUDController : MonoBehaviour
{
    [Header("Fills")]
    public Image healthFill;
    public Image staminaFill;
    public Image expFill;

    [Header("Texts")]
    public TMP_Text levelText;

    private PlayerProgressionController player;

    void Start()
    {
        StartCoroutine(WaitForPlayer());
    }

    IEnumerator WaitForPlayer()
    {
        while (player == null)
        {
            player = FindFirstObjectByType<PlayerProgressionController>();
            yield return null;
        }

        Debug.Log("[HUD] Player hooked");
    }

    void Update()
    {
        if (player == null)
            return;

        UpdateBars();
        UpdateLevel();
    }

    void UpdateBars()
    {
        if (healthFill && player.stats.maxHealth > 0f)
            healthFill.fillAmount = player.currentHealth / player.stats.maxHealth;

        if (staminaFill && player.stats.maxStamina > 0f)
            staminaFill.fillAmount = player.currentStamina / player.stats.maxStamina;

        if (expFill && player.xp.expToNext > 0)
            expFill.fillAmount = (float)player.xp.exp / player.xp.expToNext;
    }

    void UpdateLevel()
    {
        if (levelText)
            levelText.text = "LVL: " + player.xp.level.ToString();
    }
}
