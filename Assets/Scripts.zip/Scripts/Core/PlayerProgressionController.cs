using System;
using System.Collections.Generic;
using UnityEngine;
using GrassSim.Stats;
using GrassSim.Upgrades;
using GrassSim.Progression;

namespace GrassSim.Core
{
    public class PlayerProgressionController : MonoBehaviour
    {
        [Header("Base stats")]
        public PlayerStatsData baseStats;

        [Header("Upgrades")]
        public UpgradeLibrary upgradeLibrary;

        [Header("Runtime")]
        public RuntimeStats stats;
        public PlayerExperience xp = new PlayerExperience();

        [Header("Current resources")]
        [SerializeField] public float currentHealth;
        [SerializeField] public float currentStamina;

        public float CurrentHealth => currentHealth;
        public float MaxHealth => stats.maxHealth;
        public float CurrentStamina => currentStamina;
        public float MaxStamina => stats.maxStamina;

        public bool IsDead => currentHealth <= 0f;
        public bool IsChoosingUpgrade { get; private set; }

        // Hook for UI
        public event Action<List<UpgradeOption>> OnLevelUpOptionsRolled;
        public event Action<bool> OnUpgradeMenuStateChanged;
        public event Action OnStatsChanged;

        public AudioSource audioSource;
        public AudioClip upgradeClick;

        private int rollCounter = 0;

        private void Awake()
        {
            if (baseStats == null)
                Debug.LogError("PlayerProgressionController: baseStats not assigned.", this);

            stats = new RuntimeStats(baseStats);
            currentHealth = stats.maxHealth;
            currentStamina = stats.maxStamina;
        }

        private void Update()
        {
            TickRegen(Time.deltaTime);
        }

        private void TickRegen(float dt)
        {
            if (stats.healthRegen > 0f && currentHealth < stats.maxHealth)
            {
                currentHealth = Mathf.Min(
                    stats.maxHealth,
                    currentHealth + stats.healthRegen * dt
                );
            }

            if (stats.staminaRegen > 0f && currentStamina < stats.maxStamina)
            {
                currentStamina = Mathf.Min(
                    stats.maxStamina,
                    currentStamina + stats.staminaRegen * dt
                );
            }
        }

        // ================= DAMAGE / HEAL =================

        public void TakeDamage(float amount)
        {
            if (amount <= 0f || IsDead)
                return;

            float dodgeChance = stats.dodgeChance;
            if (dodgeChance > 0f && UnityEngine.Random.value < dodgeChance)
            {
                SpawnCombatText("Dodge", Color.white);
                return;
            }

            float finalAmount = amount;
            float blocked = 0f;

            float reduction = Mathf.Clamp01(stats.damageReduction);
            if (reduction > 0f)
            {
                blocked = amount * reduction;
                finalAmount = amount - blocked;
            }
            
            currentHealth = Mathf.Max(0f, currentHealth - finalAmount);

            if (IsDead)
                SendMessage("OnCombatantDied", SendMessageOptions.DontRequireReceiver);
        }

        public void Heal(float amount)
        {
            if (amount <= 0f || IsDead)
                return;

            currentHealth = Mathf.Min(stats.maxHealth, currentHealth + amount);
        }

        // ================= STAMINA =================

        public bool TrySpendStamina(float cost)
        {
            if (cost <= 0f) return true;
            if (currentStamina < cost) return false;
 
            currentStamina -= cost;
            return true;
        }

        public void AddStamina(float amount)
        {
            if (amount <= 0f) return;
            currentStamina = Mathf.Min(stats.maxStamina, currentStamina + amount);
        }

        // ================= EXPERIENCE =================

        public void AddExp(int amount)
        {
            bool leveled = xp.AddExp(amount);
            if (leveled)
                RollLevelUpOptions();
        }

        private void RollLevelUpOptions()
        {
            if (upgradeLibrary == null)
                return;

            IsChoosingUpgrade = true;

            OnUpgradeMenuStateChanged?.Invoke(true);

            Time.timeScale = 0f;

            int seed = unchecked(Environment.TickCount + (rollCounter++ * 10007));
            var options = upgradeLibrary.RollOptions(3, seed);

            OnLevelUpOptionsRolled?.Invoke(options);
        }

        public void ApplyUpgrade(UpgradeOption option)
        {
            if (option == null) return;

            float oldMaxHp = stats.maxHealth;
            float oldMaxStam = stats.maxStamina;

            stats.Apply(option.stat, option.value);

            if (stats.maxHealth != oldMaxHp && oldMaxHp > 0f)
                currentHealth = Mathf.Clamp(
                    stats.maxHealth * (currentHealth / oldMaxHp),
                    1f,
                    stats.maxHealth
                );

            if (stats.maxStamina != oldMaxStam && oldMaxStam > 0f)
                currentStamina = Mathf.Clamp(
                    stats.maxStamina * (currentStamina / oldMaxStam),
                    0f,
                    stats.maxStamina
                );

            IsChoosingUpgrade = false;

            audioSource.PlayOneShot(upgradeClick, 1f);

            OnStatsChanged?.Invoke();
            OnUpgradeMenuStateChanged?.Invoke(false);

            Time.timeScale = 1f;
        }

        private void SpawnCombatText(object value, Color color)
        {
            if (FloatingTextSystem.Instance == null)
                return;

            Vector3 pos = transform.position + Vector3.up * 1.8f;

            if (value is float f)
                FloatingTextSystem.Instance.Spawn(pos, f, color, 42f);
            else
                FloatingTextSystem.Instance.SpawnText(pos, value.ToString(), color, 42f);
        }
    }
}
