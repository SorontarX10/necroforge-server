using System.IO;
using UnityEngine;

public class LoggerToFile : MonoBehaviour
{
    private string logFilePath;

    void Awake()
    {
        // ścieżka zapisu
        logFilePath = Path.Combine(Application.persistentDataPath, "debug_log.txt");

        // opcjonalnie wyczyść stary plik przy starcie
        if (File.Exists(logFilePath))
            File.Delete(logFilePath);

        // subskrybuj event logów
        Application.logMessageReceived += HandleLog;
    }

    void OnDestroy()
    {
        // odsubskrybuj
        Application.logMessageReceived -= HandleLog;
    }

    void HandleLog(string logString, string stackTrace, LogType type)
    {
        string entry = $"{System.DateTime.Now:HH:mm:ss.fff} [{type}] {logString}";

        if (type == LogType.Exception || type == LogType.Error)
            entry += "\n" + stackTrace;

        try
        {
            File.AppendAllText(logFilePath, entry + "\n");
        }
        catch (System.Exception e)
        {
            Debug.LogError("LoggerToFile: could not write to log file: " + e.Message);
        }
    }

    public string GetLogPath()
    {
        return logFilePath;
    }
}
