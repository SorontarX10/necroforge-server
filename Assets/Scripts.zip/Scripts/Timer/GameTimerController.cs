using UnityEngine;
using System;

public class GameTimerController : MonoBehaviour
{
    public static GameTimerController Instance { get; private set; }

    [Header("Timer")]
    public float elapsedTime { get; private set; }

    [Header("Phase thresholds (seconds)")]
    public float phaseBTime = 300f; // X
    public float phaseCTime = 600f; // X
    public float endGameTime = 900f; // Z

    public enum TimerPhase
    {
        PhaseA,
        PhaseB,
        PhaseC,
        End
    }

    public TimerPhase CurrentPhase { get; private set; } = TimerPhase.PhaseA;

    public event Action<float> OnTimerTick;
    public event Action<TimerPhase> OnPhaseChanged;
    public event Action OnGameEnded;

    private bool gameEnded;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Update()
    {
        if (gameEnded) return;

        elapsedTime += Time.deltaTime;
        OnTimerTick?.Invoke(elapsedTime);

        UpdatePhase();
    }

    private void UpdatePhase()
    {
        if (elapsedTime >= endGameTime && !gameEnded)
        {
            gameEnded = true;
            CurrentPhase = TimerPhase.End;
            OnPhaseChanged?.Invoke(CurrentPhase);
            OnGameEnded?.Invoke();
            return;
        }

        if (elapsedTime >= phaseBTime && CurrentPhase == TimerPhase.PhaseA)
        {
            CurrentPhase = TimerPhase.PhaseB;
            OnPhaseChanged?.Invoke(CurrentPhase);
        }

        if (elapsedTime >= phaseCTime && CurrentPhase == TimerPhase.PhaseB)
        {
            CurrentPhase = TimerPhase.PhaseC;
            OnPhaseChanged?.Invoke(CurrentPhase);
        }
    }
}
