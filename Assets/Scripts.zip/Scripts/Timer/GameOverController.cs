using UnityEngine;

public class GameOverController : MonoBehaviour
{
    public GameOverUIController gameOverUI;

    private bool ended;

    private void Start()
    {
        GameTimerController.Instance.OnGameEnded += OnTimeEnded;
    }

    public void OnPlayerDied()
    {
        if (ended) return;
        EndGame();
    }

    private void OnTimeEnded()
    {
        if (ended) return;
        EndGame();
    }

    private void EndGame()
    {
        ended = true;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        Time.timeScale = 0f;

        var stats = GameRunStats.Collect();
        gameOverUI.Show(stats);
    }
}
