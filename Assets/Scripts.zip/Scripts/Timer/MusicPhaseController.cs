using UnityEngine;
using System.Collections;

public class MusicPhaseController : MonoBehaviour
{
    [Header("Audio Sources")]
    public AudioSource musicA;
    public AudioSource musicB;
    public AudioSource musicC;

    [Header("Fade Settings")]
    public float fadeDuration = 2.5f;

    private Coroutine fadeRoutine;
    private AudioSource current;

    private void Start()
    {
        // Wszystkie grają od startu – preload
        musicA.volume = 1f;
        musicB.volume = 0f;
        musicC.volume = 0f;

        musicA.Play();
        musicB.Play();
        musicC.Play();

        current = musicA;

        GameTimerController.Instance.OnPhaseChanged += OnPhaseChanged;
    }

    private void OnPhaseChanged(GameTimerController.TimerPhase phase)
    {
        switch (phase)
        {
            case GameTimerController.TimerPhase.PhaseB:
                StartCrossfade(musicB);
                break;

            case GameTimerController.TimerPhase.PhaseC:
                StartCrossfade(musicC);
                break;
        }
    }

    private void StartCrossfade(AudioSource next)
    {
        if (current == next)
            return;

        if (fadeRoutine != null)
            StopCoroutine(fadeRoutine);

        fadeRoutine = StartCoroutine(Crossfade(current, next));
        current = next;
    }

    private IEnumerator Crossfade(AudioSource from, AudioSource to)
    {
        float t = 0f;
        float fromStart = from.volume;
        float toStart = to.volume;

        while (t < fadeDuration)
        {
            t += Time.unscaledDeltaTime;
            float k = t / fadeDuration;

            from.volume = Mathf.Lerp(fromStart, 0f, k);
            to.volume = Mathf.Lerp(toStart, 1f, k);

            yield return null;
        }

        from.volume = 0f;
        to.volume = 1f;
    }
}
