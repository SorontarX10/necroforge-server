using System.Collections.Generic;
using UnityEngine;
using GrassSim.Stats;

namespace GrassSim.AI
{
    public class EnemySimulationManager : MonoBehaviour
    {
        public static EnemySimulationManager Instance { get; private set; }

        [Header("Enemy Types")]
        public List<EnemySpawnEntry> enemyTypes = new();

        [Header("Population")]
        public int baseEnemies = 40;

        [Header("Spawn Area")]
        public float spawnRadius = 45f;
        public float minSpawnDistanceFromPlayer = 60f;
        public float maxSimDistanceFromPlayer = 120f;

        private readonly Dictionary<int, EnemySimState> sim = new();
        private int nextId = 1;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        public IEnumerable<EnemySimState> GetAll() => sim.Values;

        /// <summary>
        /// Docelowa liczba enemy w symulacji (skaluje się z difficulty)
        /// </summary>
        public int TargetCount
        {
            get
            {
                int baseCount = baseEnemies;

                if (WorldStats.Instance == null)
                    return baseCount;

                return DifficultyContext.ScaleSpawnCap(baseCount);
            }
        }

        public void EnsurePopulation(Vector3 playerPosition)
        {
            int missing = TargetCount - sim.Count;
            if (missing <= 0)
                return;

            for (int i = 0; i < missing; i++)
                SpawnSimEnemy(playerPosition);
        }

        public void RemoveEnemy(int id)
        {
            // USUWAMY z symulacji, ALE NIE ruszamy enemiesSpawned
            sim.Remove(id);
        }

        // ============================
        // 🔥 CORE SPAWN LOGIC
        // ============================

        private void SpawnSimEnemy(Vector3 playerPosition)
        {
            if (enemyTypes == null || enemyTypes.Count == 0)
            {
                Debug.LogError("[EnemySim] No enemyTypes defined!");
                return;
            }

            int prefabIndex = PickEnemyTypeIndex();
            Vector3 pos = FindSpawnPosition(playerPosition);

            var state = new EnemySimState
            {
                id = nextId++,
                prefabIndex = prefabIndex,
                position = pos,
                anchor = pos,
                health = 100f,
                state = EnemyBrainState.Patrol
            };

            sim.Add(state.id, state);

            // 🔥 LICZYMY SPAWN *TYLKO TU*
            if (WorldStats.Instance != null)
                WorldStats.Instance.AddEnemySpawned();
        }

        // ============================
        // 🎲 WEIGHTED RANDOM
        // ============================

        private int PickEnemyTypeIndex()
        {
            float total = 0f;

            foreach (var e in enemyTypes)
                total += Mathf.Max(0f, e.spawnWeight);

            float roll = Random.Range(0f, total);
            float acc = 0f;

            for (int i = 0; i < enemyTypes.Count; i++)
            {
                acc += Mathf.Max(0f, enemyTypes[i].spawnWeight);
                if (roll <= acc)
                    return i;
            }

            return 0;
        }

        private Vector3 FindSpawnPosition(Vector3 playerPosition)
        {
            float r = Random.Range(minSpawnDistanceFromPlayer, spawnRadius);
            float a = Random.Range(0f, Mathf.PI * 2f);

            return playerPosition + new Vector3(
                Mathf.Cos(a) * r,
                0f,
                Mathf.Sin(a) * r
            );
        }

        public void RecycleFarEnemies(Vector3 playerPosition)
        {
            float maxD2 = maxSimDistanceFromPlayer * maxSimDistanceFromPlayer;

            foreach (var s in sim.Values)
            {
                Vector3 d = s.position - playerPosition;
                d.y = 0f;

                if (d.sqrMagnitude > maxD2)
                {
                    Vector3 newPos = FindSpawnPosition(playerPosition);
                    s.position = newPos;
                    s.anchor = newPos;
                }
            }
        }
    }
}
