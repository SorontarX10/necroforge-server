using UnityEngine;
using System.Collections.Generic;

public static class SimplePool
{
    static Dictionary<GameObject, Queue<GameObject>> pool = new();

    public static GameObject Get(GameObject prefab)
    {
        if (!pool.TryGetValue(prefab, out var q))
            pool[prefab] = q = new Queue<GameObject>();

        if (q.Count > 0)
        {
            var go = q.Dequeue();
            go.SetActive(true);
            return go;
        }

        var inst = Object.Instantiate(prefab);
        var po = inst.GetComponent<PooledObject>();
        if (po == null)
            po = inst.AddComponent<PooledObject>();

        po.prefab = prefab;
        return inst;
    }

    public static void Return(GameObject go)
    {
        var po = go.GetComponent<PooledObject>();
        if (po == null || po.prefab == null)
        {
            Object.Destroy(go);
            return;
        }

        go.SetActive(false);

        if (!pool.TryGetValue(po.prefab, out var q))
            pool[po.prefab] = q = new Queue<GameObject>();

        q.Enqueue(go);
    }
}
