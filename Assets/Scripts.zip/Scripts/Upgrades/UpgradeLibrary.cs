using System;
using System.Collections.Generic;
using UnityEngine;
using GrassSim.Stats;

namespace GrassSim.Upgrades
{
    [CreateAssetMenu(menuName = "GrassSim/Upgrades/UpgradeLibrary", fileName = "UpgradeLibrary")]
    public class UpgradeLibrary : ScriptableObject
    {
        [Serializable]
        public class Entry
        {
            public StatType stat;
            public float value;
            [Min(0.0001f)] public float weight = 1f;
        }

        [Header("Upgrade pool (weighted)")]
        public List<Entry> entries = new List<Entry>();

        public List<UpgradeOption> RollOptions(int count, int seed)
        {
            if (entries == null || entries.Count == 0)
                return new List<UpgradeOption>();

            System.Random rng = new System.Random(seed);

            List<Entry> temp = new List<Entry>(entries);
            List<UpgradeOption> results = new List<UpgradeOption>(count);

            for (int i = 0; i < count && temp.Count > 0; i++)
            {
                int idx = WeightedPickIndex(temp, rng);
                Entry picked = temp[idx];

                UpgradeRarity rarity = RollRarity(rng);
                float finalValue = picked.value * RarityMultiplier(rarity);

                var option = new UpgradeOption(
                    picked.stat,
                    finalValue,
                    rarity,
                    picked.stat.ToString(),
                    $"Improves {picked.stat}"
                );
                
                results.Add(option);
                temp.RemoveAt(idx);
            }

            return results;
        }

        private static int WeightedPickIndex(List<Entry> list, System.Random rng)
        {
            double total = 0;
            foreach (var e in list)
                total += Math.Max(0.0001f, e.weight);

            double roll = rng.NextDouble() * total;

            double acc = 0;
            for (int i = 0; i < list.Count; i++)
            {
                acc += Math.Max(0.0001f, list[i].weight);
                if (roll <= acc)
                    return i;
            }

            return list.Count - 1;
        }

        private UpgradeRarity RollRarity(System.Random rng)
        {
            double r = rng.NextDouble();

            if (r < 0.02) return UpgradeRarity.Mythic;     // fiolet
            if (r < 0.07) return UpgradeRarity.Legendary;  // złoty
            if (r < 0.20) return UpgradeRarity.Rare;
            if (r < 0.45) return UpgradeRarity.Uncommon;
            return UpgradeRarity.Common;
        }


        private float RarityMultiplier(UpgradeRarity r)
        {
            return r switch
            {
                UpgradeRarity.Common => 1f,
                UpgradeRarity.Uncommon => 1.25f,
                UpgradeRarity.Rare => 1.5f,
                UpgradeRarity.Legendary => 2f,   // GOLD
                UpgradeRarity.Mythic => 3f,       // PURPLE
                _ => 1f
            };
        }
    }
}
