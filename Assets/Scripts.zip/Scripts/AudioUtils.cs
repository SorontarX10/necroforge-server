using UnityEngine;

public static class AudioUtils
{
    public static void PlayClipAtPoint(AudioClip clip, Vector3 pos, float volume = 1f)
    {
        if (clip == null) return;

        GameObject go = new GameObject("OneShotAudio");
        go.transform.position = pos;

        AudioSource src = go.AddComponent<AudioSource>();
        src.clip = clip;
        src.volume = volume;
        src.spatialBlend = 1f;
        src.Play();

        Object.Destroy(go, clip.length + 0.1f);
    }
}
