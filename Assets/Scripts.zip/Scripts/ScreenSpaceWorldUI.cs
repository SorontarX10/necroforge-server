using UnityEngine;
using UnityEngine.UI;

public class ScreenSpaceWorldUI : MonoBehaviour
{
    public Transform target;
    public Vector3 worldOffset = Vector3.up * 2f;

    private RectTransform rect;
    private CanvasGroup canvasGroup;
    private Camera mainCam;

    void Awake()
    {
        rect = GetComponent<RectTransform>();
        canvasGroup = GetComponent<CanvasGroup>() ?? gameObject.AddComponent<CanvasGroup>();
        mainCam = Camera.main;
    }

    void LateUpdate()
    {
        if (target == null || mainCam == null) return;

        Vector3 screenPos = mainCam.WorldToScreenPoint(target.position + worldOffset);
        if (screenPos.z > 0f)
        {
            rect.position = screenPos;
            rect.localScale = GetScaleByDistance();
            gameObject.SetActive(true);
        }
        else
            gameObject.SetActive(false);
    }

    Vector3 GetScaleByDistance()
    {
        float distance = Vector3.Distance(mainCam.transform.position, target.position);
        float scale = Mathf.Clamp(1f / (distance * 0.07f), 0.5f, 1.2f);
        return new Vector3(scale, scale, scale);
    }
}
