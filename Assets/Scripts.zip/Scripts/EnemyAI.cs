using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(Collider))]
public class EnemyAI : MonoBehaviour
{
    [Header("Wander / Chase Settings")]
    public float wanderRadius = 5f;
    public float wanderIntervalMin = 2f;
    public float wanderIntervalMax = 5f;
    public float wanderSpeed = 2f;

    public float detectionRadius = 8f;
    public float chaseSpeed = 3.5f;

    [Header("Attack Settings")]
    public float attackRadius = 2.2f;      // zasięg ataku
    public float attackCooldown = 1.5f;    // czas między atakami
    private float lastAttackTime = -999f;

    private Vector3 initialPosition;
    private Vector3 wanderTarget;
    private float nextWanderTime;

    private Transform player;
    private Rigidbody rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        // Blokuj rotacje w osiach X i Z, by wróg się nie przewracał przy kolizjach
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

        initialPosition = transform.position;
        ChooseNewWanderTarget();

        GameObject p = GameObject.FindGameObjectWithTag("Player");
        if (p != null) player = p.transform;
        else Debug.LogWarning("EnemyAI: nie znaleziono obiektu z tag 'Player'");
    }

    void FixedUpdate()
    {
        if (player != null)
        {
            float dist = Vector3.Distance(transform.position, player.position);
            if (dist <= attackRadius)
            {
                TryAttack();
                return;
            }
            else if (dist <= detectionRadius)
            {
                ChasePlayerPhysics();
                return;
            }
        }

        WanderPhysics();
    }

    void TryAttack()
    {
        if (Time.time - lastAttackTime < attackCooldown)
            return;

        lastAttackTime = Time.time;
        PerformAttackMotion();
    }

    void PerformAttackMotion()
    {
        Vector3 dir = player.position - transform.position;
        dir.y = 0f;
        if (dir.sqrMagnitude < 0.01f)
            return;

        // Obróć się w stronę gracza
        Quaternion targetRot = Quaternion.LookRotation(dir.normalized);
        rb.MoveRotation(targetRot);

        // (Opcjonalnie) możesz dodać sam atak — np. wyrzut miecza, animację, siłę
        // Zakładamy, że broń w hierarchy ma swój Rigidbody + kolider + skrypt obrażeń
        // i fizyka zadziała przy kolizji
    }

    void ChasePlayerPhysics()
    {
        Vector3 dir = player.position - transform.position;
        dir.y = 0f;
        float dist = dir.magnitude;
        if (dist > 0.05f)
        {
            Vector3 moveDir = dir.normalized;
            Vector3 desiredVelocity = moveDir * chaseSpeed;
            rb.MovePosition(rb.position + desiredVelocity * Time.fixedDeltaTime);

            Quaternion targetRot = Quaternion.LookRotation(moveDir);
            rb.MoveRotation(Quaternion.RotateTowards(rb.rotation, targetRot, 720f * Time.fixedDeltaTime));
        }
    }

    void WanderPhysics()
    {
        if (Time.time >= nextWanderTime)
        {
            ChooseNewWanderTarget();
        }

        Vector3 dir = wanderTarget - transform.position;
        dir.y = 0f;
        float dist = dir.magnitude;
        if (dist > 0.2f)
        {
            Vector3 moveDir = dir.normalized;
            Vector3 desiredVelocity = moveDir * wanderSpeed;
            rb.MovePosition(rb.position + desiredVelocity * Time.fixedDeltaTime);

            Quaternion targetRot = Quaternion.LookRotation(moveDir);
            rb.MoveRotation(Quaternion.RotateTowards(rb.rotation, targetRot, 720f * Time.fixedDeltaTime));
        }
    }

    void ChooseNewWanderTarget()
    {
        Vector2 rand2 = Random.insideUnitCircle * wanderRadius;
        wanderTarget = initialPosition + new Vector3(rand2.x, 0f, rand2.y);
        nextWanderTime = Time.time + Random.Range(wanderIntervalMin, wanderIntervalMax);
    }
}
