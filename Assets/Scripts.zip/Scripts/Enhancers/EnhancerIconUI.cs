using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace GrassSim.Enhancers
{
    public class EnhancerIconUI : MonoBehaviour
    {
        [Header("Refs")]
        [SerializeField] private Image icon;
        [SerializeField] private Image timerFill;
        [SerializeField] private TMP_Text stackText;

        private ActiveEnhancer enhancer;

        public void Bind(ActiveEnhancer active)
        {
            enhancer = active;

            if (icon != null)
                icon.sprite = active.Definition.icon;

            RefreshStatic();
        }

        private void Update()
        {
            if (enhancer == null)
            {
                Destroy(gameObject);
                return;
            }

            RefreshTimer();
        }

        private void RefreshStatic()
        {
            int stacks = enhancer.Stacks;

            if (stackText != null)
                stackText.text = stacks > 1 ? $"x{stacks}" : "";
        }

        private void RefreshTimer()
        {
            if (timerFill == null || enhancer == null)
                return;

            timerFill.fillAmount = 1f - enhancer.TimeToNextStackDrop01;

            // stack text aktualny z czasu
            if (stackText != null)
            {
                int stacks = enhancer.StacksFromTime;
                stackText.text = stacks > 1 ? $"x{stacks}" : "";
            }
        }
    }
}
