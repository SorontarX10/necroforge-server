using UnityEngine;
using System.Collections.Generic;

namespace GrassSim.Enhancers
{
    public class EnhancerIconsPanelUI : MonoBehaviour
    {
        [Header("UI")]
        [SerializeField] private EnhancerIconUI iconPrefab;
        [SerializeField] private Transform iconsRoot;

        private WeaponEnhancerSystem system;
        private readonly Dictionary<ActiveEnhancer, EnhancerIconUI> icons = new();

        private void Start()
        {
            InvokeRepeating(nameof(TryResolveSystem), 0f, 0.25f);
        }

        private void TryResolveSystem()
        {
            if (system != null)
                return;

            system = FindFirstObjectByType<WeaponEnhancerSystem>();
            if (system == null)
                return;

            system.OnChanged += Refresh;
            Refresh();
        }

        private void Refresh()
        {
            if (system == null)
                return;

            // usuń nieistniejące
            var keys = new List<ActiveEnhancer>(icons.Keys);
            for (int i = 0; i < keys.Count; i++)
            {
                var key = keys[i];

                bool stillActive = false;
                for (int j = 0; j < system.Active.Count; j++)
                {
                    if (system.Active[j] == key)
                    {
                        stillActive = true;
                        break;
                    }
                }

                if (!stillActive)
                {
                    Destroy(icons[key].gameObject);
                    icons.Remove(key);
                }
            }

            // dodaj nowe
            for (int i = 0; i < system.Active.Count; i++)
            {
                var enhancer = system.Active[i];
                if (enhancer == null) continue;

                if (icons.ContainsKey(enhancer))
                    continue;

                var icon = Instantiate(iconPrefab, iconsRoot);
                icon.Bind(enhancer);
                icons.Add(enhancer, icon);
            }
        }

        private void OnDestroy()
        {
            if (system != null)
                system.OnChanged -= Refresh;
        }
    }
}
