using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;

public class LoadingController : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private Camera loadingCamera;
    [SerializeField] private Canvas loadingCanvas;
    [SerializeField] private Image progressFill;

    [Header("Timing")]
    [SerializeField] private float minLoadingTime = 1.0f;

    void Start()
    {
        // 🔒 START: loading zawsze aktywny
        loadingCamera.gameObject.SetActive(true);
        loadingCanvas.gameObject.SetActive(true);

        if (progressFill != null)
            progressFill.fillAmount = 0f;

        StartCoroutine(LoadGameRoutine());
    }

    IEnumerator LoadGameRoutine()
    {
        float timer = 0f;

        // 1️⃣ ŁADUJEMY GAME ADDITIVE
        AsyncOperation op = SceneManager.LoadSceneAsync("Game", LoadSceneMode.Additive);
        op.allowSceneActivation = false;

        while (op.progress < 0.9f || timer < minLoadingTime)
        {
            timer += Time.deltaTime;

            if (progressFill != null)
            {
                // 0–0.9 → 0–0.8 paska
                float p = Mathf.Clamp01(op.progress / 0.9f);
                progressFill.fillAmount = Mathf.Lerp(0f, 0.8f, p);
            }

            yield return null;
        }

        // 2️⃣ AKTYWUJ SCENĘ
        op.allowSceneActivation = true;

        // 3️⃣ CZEKAJ NA GENERACJĘ ŚWIATA
        yield return new WaitUntil(() => ChunkedProceduralLevelGenerator.WorldReady);

        // 4️⃣ DOMKNIJ PASEK
        if (progressFill != null)
            progressFill.fillAmount = 1f;

        yield return null; // 1 klatka buforu

        // 5️⃣ ATOMOWO WYŁĄCZ LOADING
        loadingCanvas.gameObject.SetActive(false);
        loadingCamera.gameObject.SetActive(false);
    }
}
