using UnityEngine;
using TMPro;

public class FloatingText : MonoBehaviour
{
    public TMP_Text text;

    [Header("Anim")]
    public float lifetime = 0.9f;
    public float floatSpeed = 1.4f;
    public float fadeStart = 0.4f;

    private float t;
    private Color baseColor;
    private Camera cam;

    public void Init(Camera camera, string content, Color color, float fontSize)
    {
        cam = camera;

        text.text = content;
        text.color = color;
        text.fontSize = fontSize;

        baseColor = color;
        t = 0f;
    }

    void LateUpdate()
    {
        float dt = Time.unscaledDeltaTime;
        t += dt;

        transform.position += Vector3.up * floatSpeed * dt;

        // billboard
        if (cam != null)
            transform.rotation = Quaternion.LookRotation(transform.position - cam.transform.position);

        // fade
        if (t >= fadeStart)
        {
            float a = Mathf.Lerp(1f, 0f, (t - fadeStart) / (lifetime - fadeStart));
            text.color = new Color(baseColor.r, baseColor.g, baseColor.b, a);
        }

        if (t >= lifetime)
            Destroy(gameObject);
    }
}
