using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class ZombieAI : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 2.2f;
    public float rotationSpeed = 8f;
    public float attackStopDistance = 1.8f; // dystans kontaktu (NIE stopuje ruchu)

    [Header("Detection")]
    public float detectionRadius = 8f;
    public LayerMask targetLayers; // Player + Enemy (bez zombie)

    [Header("Wander")]
    public float wanderRadius = 6f;
    public float wanderInterval = 3f;

    [Header("Separation")]
    public float separationRadius = 1.4f;
    public float separationStrength = 0.4f;
    public LayerMask zombieLayer;

    Rigidbody rb;
    Transform currentTarget;

    Vector3 wanderTarget;
    float nextWanderTime;

    Animator animator;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();

        rb.useGravity = true;
        rb.constraints =
            RigidbodyConstraints.FreezeRotationX |
            RigidbodyConstraints.FreezeRotationZ;

        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.linearDamping = 3f;
        rb.angularDamping = 10f;

        animator = GetComponentInChildren<Animator>();

        PickNewWanderTarget();
    }

    void FixedUpdate()
    {
        AcquireTarget();

        Vector3 moveDir = Vector3.zero;

        if (currentTarget != null)
        {
            Vector3 toTarget = currentTarget.position - transform.position;
            toTarget.y = 0f;

            if (toTarget.sqrMagnitude > 0.001f)
                moveDir = toTarget.normalized;
        }
        else
        {
            Vector3 toWander = wanderTarget - transform.position;
            toWander.y = 0f;

            if (toWander.sqrMagnitude > 0.01f)
                moveDir = toWander.normalized;
        }

        // 🔥 separacja TYLKO gdy NIE jesteśmy przy celu
        if (currentTarget == null ||
            HorizontalDistance(transform.position, currentTarget.position) > attackStopDistance)
        {
            moveDir += ComputeSeparation() * separationStrength;
        }

        if (moveDir.sqrMagnitude > 0.001f)
        {
            moveDir.Normalize();

            Vector3 vel = rb.linearVelocity;
            vel.x = moveDir.x * moveSpeed;
            vel.z = moveDir.z * moveSpeed;
            rb.linearVelocity = vel;

            Quaternion targetRot = Quaternion.LookRotation(moveDir);
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                targetRot,
                rotationSpeed * Time.fixedDeltaTime
            );
        }
        else
        {
            rb.linearVelocity = Vector3.zero;
        }

        if (currentTarget == null && Time.time >= nextWanderTime)
            PickNewWanderTarget();

        if (animator)
            animator.SetFloat("Speed", rb.linearVelocity.magnitude);
    }

    // ======================================================
    // TARGETING
    // ======================================================

    void AcquireTarget()
    {
        Collider[] hits = Physics.OverlapSphere(
            transform.position,
            detectionRadius,
            targetLayers,
            QueryTriggerInteraction.Ignore
        );

        float best = float.MaxValue;
        Transform bestTarget = null;

        foreach (var h in hits)
        {
            if (!h) continue;
            if (h.transform == transform) continue;

            float d = (h.transform.position - transform.position).sqrMagnitude;
            if (d < best)
            {
                best = d;
                bestTarget = h.transform;
            }
        }

        currentTarget = bestTarget;
    }

    // ======================================================
    // WANDER
    // ======================================================

    void PickNewWanderTarget()
    {
        Vector2 rnd = Random.insideUnitCircle * wanderRadius;
        wanderTarget = transform.position + new Vector3(rnd.x, 0f, rnd.y);
        nextWanderTime = Time.time + wanderInterval;
    }

    // ======================================================
    // SEPARATION
    // ======================================================

    Vector3 ComputeSeparation()
    {
        Collider[] hits = Physics.OverlapSphere(
            transform.position,
            separationRadius,
            zombieLayer,
            QueryTriggerInteraction.Ignore
        );

        Vector3 force = Vector3.zero;
        int count = 0;

        foreach (var h in hits)
        {
            if (!h || h.transform == transform)
                continue;

            Vector3 diff = transform.position - h.transform.position;
            diff.y = 0f;

            float dist = diff.magnitude;
            if (dist < 0.001f) continue;

            float w = (separationRadius - dist) / separationRadius;
            force += diff.normalized * Mathf.Clamp01(w);
            count++;
        }

        if (count > 0)
            force /= count;

        return force;
    }

    static float HorizontalDistance(Vector3 a, Vector3 b)
    {
        a.y = 0f;
        b.y = 0f;
        return Vector3.Distance(a, b);
    }
}
